import React, { useState, useEffect } from 'react';
import { useModeScoringContext } from '@/lib/modeScoringContext';
import { useEngine } from '@/lib/engineContext';
import { cn } from '@/lib/utils';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { AlertCircle, Settings, Activity, Play, Square, ChevronDown } from 'lucide-react';
import { createDecisionEngine } from '@/lib/modeDecisionEngine';
import { performanceTracker } from '@/lib/modePerformanceTracker';
import ModePerformancePanel from '@/components/adaptive/ModePerformancePanel';
import ModeHistoryTimeline from '@/components/adaptive/ModeHistoryTimeline';
import ScoreCalculationDetail from '@/components/adaptive/ScoreCalculationDetail';
import ScoreSummaryGrid from '@/components/adaptive/ScoreSummaryGrid';
import DecisionTransparency from '@/components/adaptive/DecisionTransparency';

const MODES = {
  TREND_FOLLOWING: 'TREND_FOLLOWING',
  RANGE_MEAN_REVERSION: 'RANGE_MEAN_REVERSION',
  BREAKOUT: 'BREAKOUT',
  MOMENTUM: 'MOMENTUM',
  SCALPING: 'SCALPING',
  RISK_OFF: 'RISK_OFF',
  PROTECTIVE: 'PROTECTIVE'
};

const MODE_METADATA = {
  TREND_FOLLOWING: {
    name: 'Trend Takip',
    icon: '📈',
    description: 'Ana yönü takip, pullback sonrası devam',
    color: 'text-primary',
    bg: 'bg-primary/10'
  },
  RANGE_MEAN_REVERSION: {
    name: 'Range / Ortalamaya Dönüş',
    icon: '↔️',
    description: 'Yatay piyasa, bant uçlarından işlem',
    color: 'text-blue-400',
    bg: 'bg-blue-500/10'
  },
  BREAKOUT: {
    name: 'Kırılım',
    icon: '🔨',
    description: 'Sıkışma sonrası genişleme',
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/10'
  },
  MOMENTUM: {
    name: 'Momentum',
    icon: '⚡',
    description: 'Güçlü hareket takibi',
    color: 'text-orange-400',
    bg: 'bg-orange-500/10'
  },
  SCALPING: {
    name: 'Scalping',
    icon: '📍',
    description: 'Mikro fırsatları topla',
    color: 'text-green-400',
    bg: 'bg-green-500/10'
  },
  RISK_OFF: {
    name: 'Risk-Off / Bekle',
    icon: '⏸️',
    description: 'Yeni işlem açma, mevcut riski azalt',
    color: 'text-red-400',
    bg: 'bg-red-500/10'
  },
  PROTECTIVE: {
    name: 'Koruyucu',
    icon: '🛡️',
    description: 'Boyut küçült, stop sıkılaştır',
    color: 'text-purple-400',
    bg: 'bg-purple-500/10'
  }
};

export default function AdaptiveMode() {
  const { 
    currentMode,
    selectedReason,
    marketRegime,
    evaluateAndSelectMode,
    modeHistory,
    lastEvaluationTime,
    latestEvaluation,
    simulatedRegime, setSimulatedRegime,
    autoMode, setAutoMode,
    latestDecision, setLatestDecision,
  } = useModeScoringContext();
  
  const { engineStatus, botConfig, startEngine, stopEngine, adaptiveMode, setAdaptiveMode } = useEngine();
  const [selectedScoreMode, setSelectedScoreMode] = useState(currentMode);
  const [expandedMode, setExpandedMode] = useState(null);
  const [decisionEngine] = useState(() => createDecisionEngine(performanceTracker));
  const [starting, setStarting] = useState(false);

  const handleToggleEngine = async () => {
    if (engineStatus.running) {
      stopEngine();
    } else {
      setStarting(true);
      if (currentMode) setAdaptiveMode(currentMode);
      await startEngine().finally(() => setStarting(false));
    }
  };

  // Simüle piyasa rejimi
  useEffect(() => {
    const interval = setInterval(() => {
      const regime = {
        timestamp: new Date().toISOString(),
        trend_strength: Math.random() * 100,
        trend_direction: Math.random() > 0.5 ? 'BULLISH' : Math.random() > 0.5 ? 'BEARISH' : 'NEUTRAL',
        structural_trend: ['WEAK', 'NET'][Math.floor(Math.random() * 2)],
        ema_alignment: ['PARTIAL', 'NET'][Math.floor(Math.random() * 2)],
        volume_alignment: Math.random() > 0.4 ? 'YES' : 'NO',
        volatility_level: ['VERY_LOW', 'LOW', 'NORMAL', 'HIGH', 'VERY_HIGH'][Math.floor(Math.random() * 5)],
        within_bands: ['PARTIAL', 'NET'][Math.floor(Math.random() * 2)],
        squeeze_detected: Math.random() > 0.7,
        volume_strength: ['WEAK', 'NORMAL', 'STRONG'][Math.floor(Math.random() * 3)],
        liquidity_quality: ['POOR', 'FAIR', 'GOOD', 'EXCELLENT'][Math.floor(Math.random() * 4)],
        spread_status: ['NORMAL', 'WIDE', 'EXCESSIVE'][Math.floor(Math.random() * 3)],
        squeeze_duration: ['SHORT', 'MEDIUM', 'LONG'][Math.floor(Math.random() * 3)],
        volume_increase: ['STARTING', 'EXPLOSIVE'][Math.floor(Math.random() * 2)],
        strong_close_outside_squeeze: Math.random() > 0.6,
        candle_size_increasing: Math.random() > 0.5,
        consecutive_strong_candles: Math.floor(Math.random() * 4),
        volume_momentum_aligned: Math.random() > 0.4,
        trend_not_settled: Math.random() > 0.5,
        micro_structure_clean: Math.random() > 0.6,
        commission_edge: Math.random() > 0.5 ? 0.001 : -0.001,
        data_flow_issue: false,
        consecutive_losses: Math.floor(Math.random() * 4),
        daily_loss_ratio: Math.random() * 0.6,
        recent_performance: 40 + Math.random() * 40,
        confidence_low: Math.random() > 0.7,
        mode_indecision: Math.random() > 0.7,
        trend_recent_performance: 30 + Math.random() * 60,
        breakout_recent_performance: 40 + Math.random() * 50
      };
      setSimulatedRegime(regime);
      
      if (autoMode) {
        const recentWinRate = 50; // simüle
        const activeTimeframes = botConfig?.active_timeframes || ['1m', '5m', '15m'];
        const aggressionLevel = botConfig?.aggression_level || 5;
        
        evaluateAndSelectMode(regime, aggressionLevel, activeTimeframes, recentWinRate);
        
        // Karar motoru - örnek BTCUSDT için
        const symbolValidation = decisionEngine.validateSymbol('BTCUSDT');
        const entryCheck = decisionEngine.checkEntryRules(currentMode, {
          trendStrength: regime.trend_strength,
          emaAligned: regime.ema_alignment === 'NET',
          priceAtBandExtreme: regime.within_bands === 'NET',
          squeezed: regime.squeeze_detected,
          volumeSpike: Math.random() * 2,
          consecutiveStrongCandles: Math.floor(Math.random() * 4),
          spreadBps: Math.random() * 10,
          liquidity: 'EXCELLENT'
        });
        const riskParams = decisionEngine.calculateRiskParameters(currentMode, aggressionLevel);
        
        const decision = decisionEngine.makeDecision(
          currentMode,
          regime,
          aggressionLevel,
          symbolValidation,
          entryCheck,
          riskParams
        );
        
        setLatestDecision(decision);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [autoMode, evaluateAndSelectMode, botConfig]);

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">Adaptif Mod Seçici</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Piyasa rejimini analizleyip otomatik olarak uygun işlem modunu seç
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Otomatik Mod</span>
            <Switch checked={autoMode} onCheckedChange={setAutoMode} />
          </div>
          <Button
            onClick={handleToggleEngine}
            disabled={starting}
            size="sm"
            className={cn(
              "gap-2 font-semibold",
              engineStatus.running
                ? "bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20"
                : "bg-primary text-primary-foreground hover:bg-primary/90"
            )}
            variant={engineStatus.running ? "outline" : "default"}
          >
            {engineStatus.running
              ? <><Square className="w-3.5 h-3.5" /> Motoru Durdur</>
              : starting
                ? <><Activity className="w-3.5 h-3.5 animate-pulse" /> Başlatılıyor...</>
                : <><Play className="w-3.5 h-3.5" /> Motoru Başlat</>
            }
          </Button>
        </div>
      </div>

      {/* Motor Durumu Uyarısı */}
      <div className={cn(
        "p-3 rounded-lg border flex items-start gap-3",
        engineStatus.running
          ? "bg-primary/10 border-primary/30"
          : "bg-yellow-500/10 border-yellow-500/30"
      )}>
        <AlertCircle className={cn("w-4 h-4 flex-shrink-0 mt-0.5", engineStatus.running ? "text-primary" : "text-yellow-500")} />
        <div className="text-sm">
          <div className={cn("font-semibold", engineStatus.running ? "text-primary" : "text-yellow-500")}>
            {engineStatus.running ? "⚡ Motor Çalışıyor" : "Motor Kapalı"}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            {engineStatus.running
              ? `Aktif Mod: ${currentMode || adaptiveMode || 'Hesaplanıyor...'} — İşlemler bu moda göre açılıyor`
              : "Adaptif mod seçim çalışıyor ancak işlem açılmıyor. Yukarıdaki butona basarak motoru başlatın."}
          </div>
        </div>
      </div>

      {/* İŞLEM KARAR MOTORU - ŞEFFAFLIK */}
      {latestDecision && (
        <>
          <DecisionTransparency decision={latestDecision} />
        </>
      )}

      {/* Aktif Mod ve Seçim Detayı */}
      <Card className="p-4 bg-gradient-to-r from-card to-secondary border-primary/20">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold flex items-center gap-2">
              {MODE_METADATA[currentMode]?.icon} {MODE_METADATA[currentMode]?.name}
            </h2>
            <p className="text-sm text-muted-foreground mt-2">{selectedReason}</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-primary">
              {latestEvaluation?.finalScores?.[currentMode]?.toFixed(1) || '--'}
            </div>
            <div className="text-xs text-muted-foreground">/100</div>
            {latestEvaluation?.selectedProbability && (
              <div className="text-xs text-primary mt-1">
                {(latestEvaluation.selectedProbability * 100).toFixed(0)}% olasılık
              </div>
            )}
          </div>
        </div>
        
        {lastEvaluationTime && (
          <div className="text-xs text-muted-foreground">
            Son güncelleme: {new Date(lastEvaluationTime).toLocaleTimeString('tr-TR')}
          </div>
        )}
      </Card>

      {/* Tüm Modlar Ozet Skorları */}
      <div>
        <h2 className="text-sm font-semibold mb-3">Mod Karşılaştırması (Normalize + Çarpan)</h2>
        {latestEvaluation && (
          <ScoreSummaryGrid 
            finalScores={latestEvaluation.finalScores}
            normalizedScores={latestEvaluation.normalizedScores}
            activeMode={currentMode}
            probabilities={latestEvaluation.probabilities}
          />
        )}
      </div>

      {/* Çarpan Özeti */}
      {latestEvaluation?.multipliers && (
        <Card className="p-4 border-border/50 bg-secondary/20">
          <h3 className="font-semibold text-sm mb-3">Uygulanan Çarpanlar</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="p-2.5 rounded-lg bg-card border border-border">
              <div className="text-xs text-muted-foreground mb-1">Timeframe</div>
              <div className="font-mono font-bold text-sm">×{latestEvaluation.multipliers.timeframe.toFixed(2)}</div>
              <div className="text-xs text-muted-foreground mt-1">Kısa TF ağırlığı</div>
            </div>
            <div className="p-2.5 rounded-lg bg-card border border-border">
              <div className="text-xs text-muted-foreground mb-1">Agresiflik</div>
              <div className="font-mono font-bold text-sm">×{latestEvaluation.multipliers.aggression.toFixed(2)}</div>
              <div className="text-xs text-muted-foreground mt-1">{botConfig?.aggression_level || 5}/10</div>
            </div>
            <div className="p-2.5 rounded-lg bg-card border border-border">
              <div className="text-xs text-muted-foreground mb-1">Performans</div>
              <div className="font-mono font-bold text-sm">×{latestEvaluation.multipliers.performance.toFixed(2)}</div>
              <div className="text-xs text-muted-foreground mt-1">Son win rate</div>
            </div>
            <div className="p-2.5 rounded-lg bg-card border border-border">
              <div className="text-xs text-muted-foreground mb-1">Volatilite</div>
              <div className="font-mono font-bold text-sm">×{latestEvaluation.multipliers.volatility.toFixed(2)}</div>
              <div className="text-xs text-muted-foreground mt-1">{simulatedRegime?.volatility_level || 'N/A'}</div>
            </div>
          </div>
        </Card>
      )}

      {/* Seçili Mod Detaylı Hesaplaması */}
      {expandedMode && latestEvaluation?.scoreDetails?.[expandedMode] && (
        <ScoreCalculationDetail 
          mode={expandedMode} 
          details={latestEvaluation.scoreDetails[expandedMode]}
        />
      )}

      {/* Tüm Modlar - Genişletilebilir Detaylar */}
      <div>
        <h3 className="text-sm font-semibold mb-3">Detaylı Skor Hesaplamalarının</h3>
        <div className="space-y-2">
          {latestEvaluation?.scoreDetails && Object.entries(latestEvaluation.scoreDetails).map(([mode, details]) => (
            <Card key={mode} className="p-3 border-border/50 cursor-pointer hover:border-primary/30" onClick={() => setExpandedMode(expandedMode === mode ? null : mode)}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1">
                  <span className="text-lg">{MODE_METADATA[mode]?.icon}</span>
                  <div className="flex-1">
                    <h4 className="text-xs font-bold">{MODE_METADATA[mode]?.name}</h4>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      Ham: {details.rawScore.toFixed(1)} / {details.maxScore}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-sm">{details.finalScore}</div>
                  <ChevronDown className={cn("w-4 h-4 text-muted-foreground mt-1 transition-transform", expandedMode === mode && "rotate-180")} />
                </div>
              </div>
              
              {expandedMode === mode && (
                <div className="mt-3 pt-3 border-t border-border">
                  <ScoreCalculationDetail mode={mode} details={details} />
                </div>
              )}
            </Card>
          ))}
        </div>
      </div>

      {/* Mod Seçim Kuralları */}
      <Card className="p-4 border-border/50">
        <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
          <Settings className="w-4 h-4" />
          Seçim Kuralları
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-background border border-border/50">
            <div className="font-semibold text-foreground mb-1">🔴 Risk-Off</div>
            <div className="text-muted-foreground">Spread çok geniş, likidite zayıf, volatilite aşırı yüksek</div>
          </div>
          <div className="p-3 rounded-lg bg-background border border-border/50">
            <div className="font-semibold text-foreground mb-1">🛡️ Koruyucu</div>
            <div className="text-muted-foreground">Yüksek volatilite + düşük başarı oranı</div>
          </div>
          <div className="p-3 rounded-lg bg-background border border-border/50">
            <div className="font-semibold text-foreground mb-1">🔨 Breakout</div>
            <div className="text-muted-foreground">Sıkışma tertemiz, hacim artıyor</div>
          </div>
          <div className="p-3 rounded-lg bg-background border border-border/50">
            <div className="font-semibold text-foreground mb-1">📈 Trend</div>
            <div className="text-muted-foreground">Trend gücü yüksek, hacim destekli, yönlü</div>
          </div>
          <div className="p-3 rounded-lg bg-background border border-border/50">
            <div className="font-semibold text-foreground mb-1">⚡ Momentum</div>
            <div className="text-muted-foreground">Güçlü ivme, mum gövdeleri büyük, hacim artış</div>
          </div>
          <div className="p-3 rounded-lg bg-background border border-border/50">
            <div className="font-semibold text-foreground mb-1">📍 Scalping</div>
            <div className="text-muted-foreground">Düşük spread, yüksek likidite, stabil yapı</div>
          </div>
          <div className="p-3 rounded-lg bg-background border border-border/50">
            <div className="font-semibold text-foreground mb-1">↔️ Range</div>
            <div className="text-muted-foreground">Trend yok, piyasa yatay, daralma-genişleme</div>
          </div>
        </div>
      </Card>

      {/* Mod Performansı */}
      <div>
        <h2 className="text-sm font-semibold mb-3">Modların Son Performansı</h2>
        <ModePerformancePanel />
      </div>

      {/* Mod Geçiş Tariheçesi */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <h2 className="text-sm font-semibold mb-3">Son Mod Değişiklikleri</h2>
          <ModeHistoryTimeline modeHistory={modeHistory} />
        </div>

        {/* Piyasa Rejimi Özeti */}
        {simulatedRegime && (
          <Card className="p-4 border-border/50">
            <h3 className="font-semibold text-sm mb-3">Piyasa Rejimi</h3>
            <div className="space-y-2 text-xs">
              <div>
                <div className="text-muted-foreground">Trend Gücü</div>
                <div className="font-semibold">{simulatedRegime.trend_strength.toFixed(1)}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Volatilite</div>
                <div className="font-semibold">{simulatedRegime.volatility_level}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Sıkışma</div>
                <div className="font-semibold">{simulatedRegime.squeeze_detected ? 'Var ✓' : 'Yok'}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Hacim</div>
                <div className="font-semibold">{simulatedRegime.volume_strength}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Spread</div>
                <div className="font-semibold">{simulatedRegime.spread_status}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Likidite</div>
                <div className="font-semibold">{simulatedRegime.liquidity_quality}</div>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}