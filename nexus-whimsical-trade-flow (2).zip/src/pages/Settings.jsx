import React, { useState } from 'react';
import { useEngine } from '@/lib/engineContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Eye, EyeOff, Key, Shield, Sliders, CheckCircle, AlertCircle, Loader2, Save } from 'lucide-react';
import { cn } from '@/lib/utils';
import { verifyApiKey } from '@/lib/binance';

export default function Settings() {
  const { apiConfig, botConfig, saveApiConfig, saveBotConfig, engineStatus } = useEngine();

  const [apiKey, setApiKey] = useState(apiConfig?.api_key || '');
  const [apiSecret, setApiSecret] = useState(apiConfig?.api_secret || '');
  const [isTestnet, setIsTestnet] = useState(apiConfig?.is_testnet || false);
  const [showSecret, setShowSecret] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [verifyResult, setVerifyResult] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Bot config state
  const [maxPositions, setMaxPositions] = useState(botConfig?.max_open_positions || 5);
  const [riskPerTrade, setRiskPerTrade] = useState(botConfig?.risk_per_trade_pct || 1.0);
  const [dailyLoss, setDailyLoss] = useState(botConfig?.daily_loss_limit_pct || 3.0);
  const [weeklyLoss, setWeeklyLoss] = useState(botConfig?.weekly_loss_limit_pct || 8.0);
  const [maxConsecutiveLosses, setMaxConsecutiveLosses] = useState(botConfig?.max_consecutive_losses || 4);
  const [scanCount, setScanCount] = useState(botConfig?.scan_symbols_count || 50);
  const [savingBot, setSavingBot] = useState(false);

  const handleVerify = async () => {
    if (!apiKey || !apiSecret) return;
    setVerifying(true);
    setVerifyResult(null);
    const result = await verifyApiKey(apiKey, apiSecret, isTestnet);
    setVerifyResult(result);
    setVerifying(false);
  };

  const handleSaveApi = async () => {
    setSaving(true);
    try {
      await saveApiConfig({
        api_key: apiKey,
        api_secret: apiSecret,
        is_testnet: isTestnet,
        status: verifyResult?.valid ? 'connected' : 'unverified',
        last_verified: verifyResult?.valid ? new Date().toISOString() : undefined,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  const handleSaveBot = async () => {
    setSavingBot(true);
    try {
      await saveBotConfig({
        max_open_positions: maxPositions,
        risk_per_trade_pct: riskPerTrade,
        daily_loss_limit_pct: dailyLoss,
        weekly_loss_limit_pct: weeklyLoss,
        max_consecutive_losses: maxConsecutiveLosses,
        scan_symbols_count: scanCount,
        aggression_level: engineStatus.aggrLevel,
        mode: engineStatus.mode,
      });
    } finally {
      setSavingBot(false);
    }
  };

  return (
    <div className="p-4 lg:p-6 max-w-2xl">
      <h1 className="text-xl font-bold mb-6">Ayarlar</h1>

      {/* API Configuration */}
      <div className="bg-card border border-border rounded-xl p-5 mb-4">
        <div className="flex items-center gap-2 mb-4">
          <Key className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold">Binance API Konfigürasyonu</h2>
          {apiConfig?.status === 'connected' && (
            <span className="ml-auto text-xs text-primary flex items-center gap-1">
              <CheckCircle className="w-3 h-3" /> Bağlı
            </span>
          )}
        </div>

        <div className="space-y-4">
          <div>
            <Label className="text-xs text-muted-foreground mb-1.5 block">API Anahtarı</Label>
            <Input
              value={apiKey}
              onChange={e => setApiKey(e.target.value)}
              placeholder="Binance Futures API Anahtarınızı girin"
              className="bg-secondary border-border font-mono text-xs"
            />
          </div>
          <div>
            <Label className="text-xs text-muted-foreground mb-1.5 block">API Gizli Anahtarı</Label>
            <div className="relative">
              <Input
                type={showSecret ? 'text' : 'password'}
                value={apiSecret}
                onChange={e => setApiSecret(e.target.value)}
                placeholder="API Gizli Anahtarınızı girin"
                className="bg-secondary border-border font-mono text-xs pr-10"
              />
              <button
                onClick={() => setShowSecret(!showSecret)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between py-2 border-t border-border">
            <div>
              <div className="text-sm font-medium">Testnet Modu</div>
              <div className="text-xs text-muted-foreground">Binance Futures Testnet'i kullanın</div>
            </div>
            <Switch checked={isTestnet} onCheckedChange={setIsTestnet} />
          </div>

          {verifyResult && (
            <div className={cn(
              "flex items-start gap-3 p-3 rounded-lg border text-sm",
              verifyResult.valid ? "bg-primary/10 border-primary/20" : "bg-red-500/10 border-red-500/20"
            )}>
              {verifyResult.valid
                ? <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                : <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              }
              <div>
                {verifyResult.valid ? (
                  <>
                    <div className="text-primary font-medium">API Başarıyla Bağlandı</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Bakiye: ${verifyResult.totalWalletBalance?.toFixed(2)} USDT · Kullanılabilir: ${verifyResult.availableBalance?.toFixed(2)} USDT
                    </div>
                  </>
                ) : (
                  <div className="text-red-400">{verifyResult.error}</div>
                )}
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleVerify}
              disabled={verifying || !apiKey || !apiSecret}
              className="gap-2"
            >
              {verifying ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Shield className="w-3.5 h-3.5" />}
              {verifying ? 'Doğrulanıyor...' : 'Bağlantıyı Doğrula'}
            </Button>
            <Button
              size="sm"
              onClick={handleSaveApi}
              disabled={saving || !apiKey}
              className="gap-2"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : saved ? <CheckCircle className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
              {saved ? 'Kaydedildi!' : saving ? 'Kaydediliyor...' : 'API Anahtarlarını Kaydet'}
            </Button>
          </div>
        </div>
      </div>

      {/* Risk Configuration */}
      <div className="bg-card border border-border rounded-xl p-5 mb-4">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold">Risk Yönetimi</h2>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {[
            { label: 'Max Açık Pozisyonlar', value: maxPositions, setter: setMaxPositions, min: 1, max: 50, step: 1, desc: 'Eş zamanlı açık pozisyonlar' },
            { label: 'İşlem Başına Risk (%)', value: riskPerTrade, setter: setRiskPerTrade, min: 0.1, max: 5, step: 0.1, desc: 'Her işlemde riske atılan bakiye %' },
            { label: 'Günlük Kayıp Limiti (%)', value: dailyLoss, setter: setDailyLoss, min: 0.5, max: 20, step: 0.5, desc: 'Günlük kayıp bunu aşarsa işlemler durur' },
            { label: 'Haftalık Kayıp Limiti (%)', value: weeklyLoss, setter: setWeeklyLoss, min: 1, max: 50, step: 0.5, desc: 'Haftalık kayıp bunu aşarsa işlemler durur' },
            { label: 'Max Ardışık Kayıplar', value: maxConsecutiveLosses, setter: setMaxConsecutiveLosses, min: 1, max: 10, step: 1, desc: 'Bu kadar ardışık kayıptan sonra duraklat' },
            { label: 'Taranacak Sembol Sayısı', value: scanCount, setter: setScanCount, min: 10, max: 100, step: 10, desc: 'Kaç tane USDT vadeli sözleşme taranacak' },
          ].map(f => (
            <div key={f.label}>
              <div className="flex items-center justify-between mb-1">
                <Label className="text-xs text-muted-foreground">{f.label}</Label>
                <span className="text-sm font-mono font-medium">{f.value}</span>
              </div>
              <input
                type="range"
                min={f.min} max={f.max} step={f.step}
                value={f.value}
                onChange={e => f.setter(parseFloat(e.target.value))}
                className="w-full accent-primary"
              />
              <div className="text-xs text-muted-foreground mt-0.5">{f.desc}</div>
            </div>
          ))}
        </div>

        <Button size="sm" onClick={handleSaveBot} disabled={savingBot} className="mt-4 gap-2">
          {savingBot ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
          {savingBot ? 'Kaydediliyor...' : 'Risk Ayarlarını Kaydet'}
        </Button>
      </div>

      {/* Security notice */}
      <div className="bg-secondary border border-border rounded-xl p-4">
        <div className="flex items-start gap-3">
          <Shield className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
          <div className="text-xs text-muted-foreground space-y-1">
            <div className="font-medium text-foreground">Güvenlik Uyarısı</div>
            <div>• API anahtarınızda yalnızca Futures ticaret iznini etkinleştirin</div>
            <div>• Para çekme izinlerini ASLA etkinleştirmeyin</div>
            <div>• Binance'de ek güvenlik için IP beyaz listesi yapını düşünün</div>
            <div>• API anahtarlarınız özel uygulama veritabanında saklanır</div>
          </div>
        </div>
      </div>
    </div>
  );
}