import React, { useState } from 'react';
import { useEngine } from '@/lib/engineContext';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, X, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow, format } from 'date-fns';

function PnlCell({ value, pct }) {
  const pos = value >= 0;
  return (
    <div className={cn("font-mono text-sm font-bold", pos ? "text-profit" : "text-loss")}>
      {pos ? '+' : ''}{value?.toFixed(2)}
      {pct !== undefined && <span className="text-xs ml-1 font-normal">({pos ? '+' : ''}{pct?.toFixed(2)}%)</span>}
    </div>
  );
}

export default function Positions() {
  const { openPositions, closedPositions, closePosition } = useEngine();
  const [tab, setTab] = useState('open');

  const positions = tab === 'open' ? openPositions : closedPositions;

  const totalOpenPnl = openPositions.reduce((s, p) => s + (p.unrealized_pnl || 0), 0);
  const totalClosedPnl = closedPositions.reduce((s, p) => s + (p.realized_pnl || 0), 0);
  const wins = closedPositions.filter(p => (p.realized_pnl || 0) > 0).length;
  const winRate = closedPositions.length > 0 ? (wins / closedPositions.length * 100).toFixed(0) : 0;

  return (
    <div className="p-4 lg:p-6">
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl font-bold">Pozisyonlar</h1>
        <div className="flex gap-4 text-sm">
          <div>
            <span className="text-muted-foreground">Gerçekleşmemiş: </span>
            <span className={cn("font-mono font-bold", totalOpenPnl >= 0 ? "text-profit" : "text-loss")}>
              {totalOpenPnl >= 0 ? '+' : ''}{totalOpenPnl.toFixed(2)} USDT
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Gerçekleştirilmiş: </span>
            <span className={cn("font-mono font-bold", totalClosedPnl >= 0 ? "text-profit" : "text-loss")}>
              {totalClosedPnl >= 0 ? '+' : ''}{totalClosedPnl.toFixed(2)} USDT
            </span>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        {[
          { label: 'Açık Pozisyonlar', value: openPositions.length },
          { label: 'Kapalı İşlemler', value: closedPositions.length },
          { label: 'Kazanç Oranı', value: `${winRate}%` },
          { label: 'Gerçekleştirilmiş P&L', value: `${totalClosedPnl >= 0 ? '+' : ''}$${totalClosedPnl.toFixed(2)}` },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-xl p-4 text-center">
            <div className="text-2xl font-bold font-mono">{s.value}</div>
            <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-secondary border border-border rounded-lg p-1 mb-4 w-fit">
        {[['open', 'Açık'], ['closed', 'Kapalı']].map(([t, label]) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "text-sm px-4 py-1.5 rounded-md font-medium transition-all",
              tab === t ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
            )}
          >
            {label} ({t === 'open' ? openPositions.length : closedPositions.length})
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary/50">
                {['Sembol', 'Yön', 'Giriş', 'Mevcut/Kapalı', 'Miktar', 'Lev', 'Strateji', 'P&L', tab === 'open' ? 'İşlemler' : 'Neden'].map(h => (
                  <th key={h} className="text-left text-xs font-medium text-muted-foreground px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {positions.length === 0 ? (
                <tr><td colSpan={9} className="text-center text-muted-foreground py-12">{tab === 'open' ? 'Açık' : 'Kapalı'} pozisyon yok</td></tr>
              ) : (
                positions.map(p => (
                  <tr key={p.id} className="border-b border-border/50 last:border-0 hover:bg-secondary/30 transition-colors">
                    <td className="px-4 py-3 font-bold">{p.symbol?.replace('USDT', '')}</td>
                    <td className="px-4 py-3">
                      <span className={cn("text-xs px-2 py-0.5 rounded font-bold", p.side === 'LONG' ? "bg-primary/10 text-primary" : "bg-red-500/10 text-red-400")}>
                        {p.side === 'LONG' ? 'UZUN' : 'KISA'}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs">${p.entry_price?.toFixed(4)}</td>
                    <td className="px-4 py-3 font-mono text-xs">${(p.current_price || p.close_price)?.toFixed(4)}</td>
                    <td className="px-4 py-3 font-mono text-xs">{p.quantity?.toFixed(3)}</td>
                    <td className="px-4 py-3 text-xs">{p.leverage}x</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{p.strategy?.replace(/_/g, ' ')}</td>
                    <td className="px-4 py-3">
                      <PnlCell
                        value={tab === 'open' ? p.unrealized_pnl : p.realized_pnl}
                        pct={tab === 'open' ? p.unrealized_pnl_pct : p.realized_pnl_pct}
                      />
                    </td>
                    <td className="px-4 py-3">
                      {tab === 'open' ? (
                        <Button size="sm" variant="ghost" className="h-7 text-xs text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={() => closePosition(p.id)}>
                          <X className="w-3 h-3 mr-1" /> Kapat
                        </Button>
                      ) : (
                        <span className="text-xs text-muted-foreground capitalize">{p.close_reason?.replace(/_/g, ' ').replace('stop_loss', 'stop kaybı').replace('take_profit', 'kar alım').replace('manual', 'manuel')}</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}