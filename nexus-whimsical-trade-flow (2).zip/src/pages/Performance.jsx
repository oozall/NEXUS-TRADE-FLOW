import React, { useMemo } from 'react';
import { useEngine } from '@/lib/engineContext';
import { cn } from '@/lib/utils';
import { BarChart2, TrendingUp, TrendingDown, Award } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';

function PerfStat({ label, value, sub, positive }) {
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="text-xs text-muted-foreground mb-1">{label}</div>
      <div className={cn("text-xl font-bold font-mono", positive === true ? "text-profit" : positive === false ? "text-loss" : "")}>{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
}

export default function Performance() {
  const { closedPositions } = useEngine();

  const stats = useMemo(() => {
    if (closedPositions.length === 0) return null;
    const wins = closedPositions.filter(p => (p.realized_pnl || 0) > 0);
    const losses = closedPositions.filter(p => (p.realized_pnl || 0) <= 0);
    const totalPnl = closedPositions.reduce((s, p) => s + (p.realized_pnl || 0), 0);
    const grossProfit = wins.reduce((s, p) => s + (p.realized_pnl || 0), 0);
    const grossLoss = Math.abs(losses.reduce((s, p) => s + (p.realized_pnl || 0), 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0;
    const avgWin = wins.length > 0 ? grossProfit / wins.length : 0;
    const avgLoss = losses.length > 0 ? grossLoss / losses.length : 0;
    const expectancy = (wins.length / closedPositions.length) * avgWin - (losses.length / closedPositions.length) * avgLoss;

    // Equity curve
    let equity = 10000;
    const equityCurve = closedPositions.map((p, i) => {
      equity += (p.realized_pnl || 0);
      return { trade: i + 1, equity: parseFloat(equity.toFixed(2)) };
    });

    // By strategy
    const byStrategy = {};
    closedPositions.forEach(p => {
      const s = p.strategy || 'unknown';
      if (!byStrategy[s]) byStrategy[s] = { trades: 0, pnl: 0, wins: 0 };
      byStrategy[s].trades++;
      byStrategy[s].pnl += p.realized_pnl || 0;
      if ((p.realized_pnl || 0) > 0) byStrategy[s].wins++;
    });

    // Max drawdown
    let peak = 10000, maxDD = 0, eq = 10000;
    closedPositions.forEach(p => {
      eq += (p.realized_pnl || 0);
      if (eq > peak) peak = eq;
      const dd = (peak - eq) / peak * 100;
      if (dd > maxDD) maxDD = dd;
    });

    return { wins: wins.length, losses: losses.length, totalPnl, profitFactor, expectancy, equityCurve, byStrategy, maxDD, avgWin, avgLoss };
  }, [closedPositions]);

  return (
    <div className="p-4 lg:p-6">
      <h1 className="text-xl font-bold mb-5">Performans</h1>

      {closedPositions.length === 0 ? (
        <div className="bg-card border border-border rounded-xl p-12 text-center">
          <BarChart2 className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Henüz kapalı işlem yok</p>
          <p className="text-xs text-muted-foreground mt-1">İşlemler kapatıldıktan sonra performans analitikleri görünecektir</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
            <PerfStat label="Toplam P&L" value={`${stats.totalPnl >= 0 ? '+' : ''}$${stats.totalPnl.toFixed(2)}`} positive={stats.totalPnl >= 0} />
            <PerfStat label="Kazanç Oranı" value={`${(stats.wins / closedPositions.length * 100).toFixed(0)}%`} sub={`${stats.wins}K / ${stats.losses}K`} />
            <PerfStat label="Kar Faktörü" value={stats.profitFactor === Infinity ? '∞' : stats.profitFactor.toFixed(2)} positive={stats.profitFactor >= 1.5} />
            <PerfStat label="Beklenen Değer" value={`$${stats.expectancy.toFixed(2)}`} positive={stats.expectancy > 0} />
            <PerfStat label="Max Düşüş" value={`${stats.maxDD.toFixed(1)}%`} positive={false} />
            <PerfStat label="Ort. Kazanç" value={`$${stats.avgWin.toFixed(2)}`} positive />
            <PerfStat label="Ort. Kayıp" value={`-$${stats.avgLoss.toFixed(2)}`} positive={false} />
            <PerfStat label="Toplam İşlemler" value={closedPositions.length} />
          </div>

          {/* Equity Curve */}
          <div className="bg-card border border-border rounded-xl p-4 mb-4">
            <h2 className="text-sm font-semibold mb-3">Denklik Eğrisi</h2>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={stats.equityCurve}>
                <XAxis dataKey="trade" tick={{ fontSize: 10 }} stroke="hsl(var(--border))" />
                <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--border))" />
                <Tooltip
                  contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }}
                  formatter={(v) => [`$${v.toFixed(2)}`, 'Denklik']}
                />
                <Line type="monotone" dataKey="equity" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* By Strategy */}
          <div className="bg-card border border-border rounded-xl p-4">
            <h2 className="text-sm font-semibold mb-3">Stratejiye Göre Performans</h2>
            <div className="space-y-2">
              {Object.entries(stats.byStrategy).map(([strategy, data]) => (
                <div key={strategy} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                  <div>
                    <div className="text-sm font-medium capitalize">{strategy.replace(/_/g, ' ')}</div>
                    <div className="text-xs text-muted-foreground">{data.trades} işlem · {(data.wins / data.trades * 100).toFixed(0)}% KO</div>
                  </div>
                  <span className={cn("text-sm font-bold font-mono", data.pnl >= 0 ? "text-profit" : "text-loss")}>
                    {data.pnl >= 0 ? '+' : ''}${data.pnl.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}