import React, { useState } from 'react';
import { useEngine } from '@/lib/engineContext';
import { cn } from '@/lib/utils';
import { Search, TrendingUp, TrendingDown, RefreshCw } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function Market() {
  const { marketData } = useEngine();
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('volume');

  const filtered = marketData
    .filter(m => m.symbol.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === 'volume') return b.volume - a.volume;
      if (sortBy === 'change') return Math.abs(b.priceChange) - Math.abs(a.priceChange);
      if (sortBy === 'price') return b.price - a.price;
      return 0;
    });

  const gainers = marketData.filter(m => m.priceChange > 0).sort((a, b) => b.priceChange - a.priceChange).slice(0, 5);
  const losers = marketData.filter(m => m.priceChange < 0).sort((a, b) => a.priceChange - b.priceChange).slice(0, 5);

  return (
    <div className="p-4 lg:p-6">
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl font-bold">Pazar</h1>
        <div className="text-xs text-muted-foreground">{marketData.length} USDT Vadeli sözleşme</div>
      </div>

      {/* Gainers/Losers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-5">
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-profit" />
            <span className="text-sm font-semibold text-profit">En Büyük Kazananlar</span>
          </div>
          <div className="space-y-2">
            {gainers.map(m => (
              <div key={m.symbol} className="flex items-center justify-between">
                <span className="text-sm font-medium">{m.symbol.replace('USDT', '')}</span>
                <div className="text-right">
                  <div className="text-xs font-mono text-profit">+{m.priceChange.toFixed(2)}%</div>
                  <div className="text-xs text-muted-foreground font-mono">${m.price < 1 ? m.price.toFixed(5) : m.price.toFixed(2)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <TrendingDown className="w-4 h-4 text-loss" />
            <span className="text-sm font-semibold text-loss">En Büyük Kaybedenler</span>
          </div>
          <div className="space-y-2">
            {losers.map(m => (
              <div key={m.symbol} className="flex items-center justify-between">
                <span className="text-sm font-medium">{m.symbol.replace('USDT', '')}</span>
                <div className="text-right">
                  <div className="text-xs font-mono text-loss">{m.priceChange.toFixed(2)}%</div>
                  <div className="text-xs text-muted-foreground font-mono">${m.price < 1 ? m.price.toFixed(5) : m.price.toFixed(2)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Search + sort */}
      <div className="flex gap-3 mb-4">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Sembol ara..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 bg-card border-border"
          />
        </div>
        <div className="flex gap-1 bg-secondary border border-border rounded-lg p-1">
          {[['volume', 'Hacim'], ['change', 'Değişim'], ['price', 'Fiyat']].map(([v, l]) => (
            <button
              key={v}
              onClick={() => setSortBy(v)}
              className={cn(
                "text-xs px-3 py-1.5 rounded-md font-medium transition-all",
                sortBy === v ? "bg-card text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary/50">
                {['#', 'Sembol', 'Fiyat', '24h Değişim', '24h Hacim', 'Yüksek', 'Düşük'].map(h => (
                  <th key={h} className="text-left text-xs font-medium text-muted-foreground px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((m, i) => (
                <tr key={m.symbol} className="border-b border-border/50 last:border-0 hover:bg-secondary/30 transition-colors">
                  <td className="px-4 py-2.5 text-xs text-muted-foreground">{i + 1}</td>
                  <td className="px-4 py-2.5 font-bold">{m.symbol.replace('USDT', '')}</td>
                  <td className="px-4 py-2.5 font-mono text-xs">${m.price < 1 ? m.price.toFixed(5) : m.price < 100 ? m.price.toFixed(3) : m.price.toFixed(2)}</td>
                  <td className="px-4 py-2.5">
                    <span className={cn("text-xs font-mono font-bold", m.priceChange >= 0 ? "text-profit" : "text-loss")}>
                      {m.priceChange >= 0 ? '+' : ''}{m.priceChange?.toFixed(2)}%
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-xs font-mono text-muted-foreground">
                    ${(m.volume / 1e6).toFixed(1)}M
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs">${m.high < 1 ? m.high.toFixed(5) : m.high.toFixed(2)}</td>
                  <td className="px-4 py-2.5 font-mono text-xs">${m.low < 1 ? m.low.toFixed(5) : m.low.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}