import React, { useState } from 'react';
import { useEngine } from '@/lib/engineContext';
import { cn } from '@/lib/utils';
import { Terminal, AlertCircle, AlertTriangle, Info, XCircle } from 'lucide-react';
import { format } from 'date-fns';

const levelIcons = {
  info: Info,
  warning: AlertTriangle,
  error: AlertCircle,
  critical: XCircle,
};

const levelColors = {
  info: 'text-muted-foreground',
  warning: 'text-warning',
  error: 'text-loss',
  critical: 'text-red-500',
};

export default function Logs() {
  const { systemLogs } = useEngine();
  const [filter, setFilter] = useState('all');

  const filtered = systemLogs.filter(l => filter === 'all' || l.level === filter);

  return (
    <div className="p-4 lg:p-6">
      <div className="flex items-center gap-2 mb-5">
        <Terminal className="w-5 h-5 text-primary" />
        <h1 className="text-xl font-bold">Sistem Günlükleri</h1>
      </div>

      <div className="flex gap-1 bg-secondary border border-border rounded-lg p-1 mb-4 w-fit">
        {[['all', 'Tümü'], ['info', 'Bilgi'], ['warning', 'Uyarı'], ['error', 'Hata'], ['critical', 'Kritik']].map(([f, label]) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "text-xs px-3 py-1.5 rounded-md font-medium transition-all",
              filter === f ? "bg-card text-foreground" : "text-muted-foreground hover:text-foreground"
            )}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden font-mono">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground text-sm">Henüz günlük yok</div>
        ) : (
          <div className="divide-y divide-border/50 max-h-[600px] overflow-y-auto">
            {filtered.map(log => {
              const Icon = levelIcons[log.level] || Info;
              return (
                <div key={log.id} className="flex items-start gap-3 px-4 py-2.5 hover:bg-secondary/30 transition-colors">
                  <Icon className={cn("w-3.5 h-3.5 mt-0.5 flex-shrink-0", levelColors[log.level])} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs text-muted-foreground">
                        {log.timestamp ? format(new Date(log.timestamp), 'HH:mm:ss') : ''}
                      </span>
                      <span className="text-xs text-muted-foreground bg-secondary px-1.5 py-0.5 rounded capitalize">
                        {log.category}
                      </span>
                    </div>
                    <div className={cn("text-xs mt-0.5", levelColors[log.level])}>{log.message}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}