import React, { useState, useEffect, useMemo } from 'react';
import { useEngine } from '@/lib/engineContext';
import { useModeScoringContext } from '@/lib/modeScoringContext';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { TrendingUp, TrendingDown, BarChart3, Save, Loader2, Trash2, Info } from 'lucide-react';
import StrategyBuilder from '@/components/strategies/StrategyBuilder';
import { toast } from 'sonner';

const strategyDefs = [
  {
    id: 'trend_continuation',
    name: 'Trend Devamı',
    desc: 'Mevcut trendi takip eder, EMA crossovers kullanır',
    icon: '📈'
  },
  {
    id: 'breakout_expansion',
    name: 'Kırılım Genişlemesi',
    desc: 'Direnç seviyeleri kırıldığında girer, momentum tradeları',
    icon: '🔨'
  },
  {
    id: 'squeeze_momentum',
    name: 'Sıkışma Momentumu',
    desc: 'Bollinger Bands sıkışması sonrası volatilite artışında girer',
    icon: '💥'
  },
  {
    id: 'momentum_burst',
    name: 'Momentum Patlaması',
    desc: 'RSI ve volume spike ile güçlü momentumu yakalar',
    icon: '⚡'
  },
  {
    id: 'mean_reversion',
    name: 'Ortalamaya Dönüş',
    desc: 'Aşırı alınmış/satılmış seviyelerinde contra trades',
    icon: '🔄'
  },
  {
    id: 'pullback_continuation',
    name: 'Geri Çekilme Devamı',
    desc: 'Pullback sonrası trend devamında girer',
    icon: '📉'
  },
];

// Performans verileri
const performanceData = {
  trend_continuation: { trades: 24, wins: 16, pnl: 342.50, winRate: 67 },
  breakout_expansion: { trades: 18, wins: 11, pnl: 285.30, winRate: 61 },
  squeeze_momentum: { trades: 22, wins: 14, pnl: 198.75, winRate: 64 },
  momentum_burst: { trades: 15, wins: 12, pnl: 456.20, winRate: 80 },
  mean_reversion: { trades: 19, wins: 9, pnl: -125.40, winRate: 47 },
  pullback_continuation: { trades: 28, wins: 10, pnl: -287.60, winRate: 36 },
};

// Her stratejinin hangi adaptif modda en iyi çalıştığı
const STRATEGY_BEST_MODES = {
  trend_continuation:   ['TREND_FOLLOWING'],
  breakout_expansion:   ['BREAKOUT'],
  squeeze_momentum:     ['BREAKOUT', 'MOMENTUM'],
  momentum_burst:       ['MOMENTUM', 'SCALPING'],
  mean_reversion:       ['RANGE_MEAN_REVERSION'],
  pullback_continuation:['TREND_FOLLOWING', 'MOMENTUM'],
};

const MODE_LABELS = {
  TREND_FOLLOWING:      'Trend Takip',
  RANGE_MEAN_REVERSION: 'Range/Ortalama',
  BREAKOUT:             'Kırılım',
  MOMENTUM:             'Momentum',
  SCALPING:             'Scalping',
  RISK_OFF:             'Risk-Off',
  PROTECTIVE:           'Koruyucu',
};

// Piyasa uygunluk puanı hesapla (0-100)
function calcMarketFit(strategyId, currentMode, latestEvaluation) {
  const bestModes = STRATEGY_BEST_MODES[strategyId];
  if (!bestModes || !currentMode) return null;

  // Eğer aktif mod bu stratejinin ideal modlarından biriyse yüksek skor
  const isBestMode = bestModes.includes(currentMode);

  // latestEvaluation'dan o modların skorlarını al
  let modeScore = 0;
  if (latestEvaluation?.finalScores) {
    const scores = bestModes.map(m => latestEvaluation.finalScores[m] || 0);
    modeScore = Math.max(...scores);
  }

  // Risk-Off veya Protective aktifse tüm stratejiler düşük puan
  if (currentMode === 'RISK_OFF' || currentMode === 'PROTECTIVE') {
    return { score: isBestMode ? 20 : 10, label: 'Zayıf', reason: `${MODE_LABELS[currentMode]} — işlem açma önerilmez`, color: 'text-loss' };
  }

  if (isBestMode) {
    const score = 60 + Math.min(40, modeScore * 0.4);
    return { score: Math.round(score), label: 'Güçlü', reason: `${MODE_LABELS[currentMode]} modu bu strateji için ideal`, color: 'text-profit' };
  } else {
    const score = Math.max(10, modeScore * 0.3);
    return { score: Math.round(score), label: 'Zayıf', reason: `Aktif mod: ${MODE_LABELS[currentMode]} — bu strateji için uygun değil`, color: 'text-loss' };
  }
}

// Custom stratejiler için — timeframe ve entry_signal'dan mod tahmini
function guessCustomStrategyModes(strategy) {
  if (!strategy) return [];
  const text = ((strategy.entry_signal || '') + ' ' + (strategy.description || '') + ' ' + (strategy.name || '')).toLowerCase();
  const modes = [];
  if (text.match(/trend|ema|sma|yön|devam/)) modes.push('TREND_FOLLOWING');
  if (text.match(/breakout|kırılım|direnç|destek|squeeze/)) modes.push('BREAKOUT');
  if (text.match(/momentum|rsi|hız|ivme|güçlü/)) modes.push('MOMENTUM');
  if (text.match(/range|yatay|ortalama|dönüş|reversion/)) modes.push('RANGE_MEAN_REVERSION');
  if (text.match(/scalp|hızlı|1m|kısa/)) modes.push('SCALPING');
  return modes.length ? modes : ['TREND_FOLLOWING'];
}

function CustomStrategyFitBadge({ strategy, currentMode }) {
  const bestModes = guessCustomStrategyModes(strategy);
  const isGood = bestModes.includes(currentMode);
  const modeLabel = currentMode.replace(/_/g, ' ');
  if (currentMode === 'RISK_OFF' || currentMode === 'PROTECTIVE') {
    return (
      <div className="mb-2 px-2 py-1.5 rounded-lg bg-loss/10 border border-loss/20 text-xs text-loss">
        ⚠️ {modeLabel} — işlem açma önerilmez
      </div>
    );
  }
  return (
    <div className={cn("mb-2 px-2 py-1.5 rounded-lg border text-xs flex items-center gap-1.5",
      isGood ? "bg-profit/10 border-profit/20 text-profit" : "bg-secondary border-border text-muted-foreground"
    )}>
      {isGood ? '✅' : '⬜'} 
      <span>{isGood ? `${modeLabel} modu için uygun` : `Aktif mod: ${modeLabel} — uyum düşük`}</span>
    </div>
  );
}

function MarketFitBar({ fit }) {
  const barColor = fit.score >= 60 ? 'bg-profit' : fit.score >= 35 ? 'bg-yellow-400' : 'bg-loss';
  return (
    <div className="mb-2 p-2 rounded-lg bg-secondary/60 border border-border/50">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-muted-foreground">Piyasa Uyumu</span>
        <span className={cn("text-xs font-bold", fit.color)}>{fit.score}/100 — {fit.label}</span>
      </div>
      <div className="w-full h-1.5 bg-border rounded-full overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", barColor)} style={{ width: `${fit.score}%` }} />
      </div>
      <div className="text-xs text-muted-foreground mt-1 leading-tight">{fit.reason}</div>
    </div>
  );
}

export default function Strategies() {
  const { botConfig, saveBotConfig } = useEngine();
  const { currentMode, latestEvaluation } = useModeScoringContext();
  const [enabled, setEnabled] = useState(botConfig?.enabled_strategies || []);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [customStrategies, setCustomStrategies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserStrategies();
  }, []);

  const loadUserStrategies = async () => {
    try {
      const userStrategies = await base44.entities.UserStrategy.list();
      const converted = userStrategies.map(s => ({
        id: s.id,
        name: s.name,
        desc: s.description,
        icon: '⭐',
        custom: true,
        is_db: true,
        strategy: s
      }));
      setCustomStrategies(converted);
    } catch (error) {
      console.log('UserStrategy yükleme:', error.message);
    } finally {
      setLoading(false);
    }
  };

  const toggleStrategy = (strategyId) => {
    setEnabled(prev =>
      prev.includes(strategyId)
        ? prev.filter(s => s !== strategyId)
        : [...prev, strategyId]
    );
    setSaved(false);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveBotConfig({
        ...botConfig,
        enabled_strategies: enabled,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  const handleStrategyCreate = async (newStrategy) => {
    // Yeni strateji ekle ve listeye göster
    const strategyId = newStrategy.name.toLowerCase().replace(/\s+/g, '_');
    const newCustomStrategy = {
      id: strategyId,
      name: newStrategy.name,
      desc: newStrategy.description,
      icon: '⭐',
      custom: true,
      strategy: newStrategy
    };
    
    setCustomStrategies(prev => [...prev, newCustomStrategy]);
    toast.success(`"${newStrategy.name}" stratejisi oluşturuldu!`);
  };

  const deleteCustomStrategy = async (strategyId) => {
    try {
      await base44.entities.UserStrategy.delete(strategyId);
      setCustomStrategies(prev => prev.filter(s => s.id !== strategyId));
      setEnabled(prev => prev.filter(s => s !== strategyId));
      toast.success('Strateji silindi!');
    } catch (error) {
      toast.error('Silinemiyor: ' + error.message);
    }
  };

  if (loading) {
    return (
      <div className="p-4 lg:p-6 flex items-center justify-center h-screen">
        <div className="w-10 h-10 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold">Strateji Yönetimi</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Yapay zekanın kullanacağı stratejileri seçin veya yeni strateji oluşturun
          </p>
        </div>
        <div className="flex gap-3">
          <StrategyBuilder onSave={handleStrategyCreate} />
          <Button
            onClick={handleSave}
            disabled={saving}
            size="sm"
            className="gap-2"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : saved ? '✓' : <Save className="w-3.5 h-3.5" />}
            {saved ? 'Kaydedildi' : saving ? 'Kaydediliyor...' : 'Ayarları Kaydet'}
          </Button>
        </div>
      </div>

      {/* Varsayılan Stratejiler */}
      <div className="mb-6">
        <h2 className="text-sm font-semibold mb-3 text-muted-foreground">Varsayılan Stratejiler</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {strategyDefs.map(strategy => {
            const perf = performanceData[strategy.id] || {};
            const isEnabled = enabled.includes(strategy.id);
            const fit = calcMarketFit(strategy.id, currentMode, latestEvaluation);

            return (
              <div
                key={strategy.id}
                className={cn(
                  "bg-card border rounded-lg p-3 transition-all flex flex-col",
                  isEnabled ? "border-primary/30 ring-1 ring-primary/10" : "border-border",
                  fit?.score >= 60 && "ring-1 ring-profit/20"
                )}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-start gap-2 flex-1 min-w-0">
                    <div className="text-lg flex-shrink-0">{strategy.icon}</div>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-xs font-bold truncate">{strategy.name}</h3>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{strategy.desc}</p>
                    </div>
                  </div>
                  <Switch
                    checked={isEnabled}
                    onCheckedChange={() => toggleStrategy(strategy.id)}
                    className="flex-shrink-0"
                  />
                </div>

                {/* Piyasa Uygunluk Puanı */}
                {fit && (
                  <MarketFitBar fit={fit} />
                )}

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border text-xs mt-2">
                  <div>
                    <div className="text-muted-foreground">İşlemler</div>
                    <div className="font-bold">{perf.trades || 0}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Kazanç Oranı</div>
                    <div className={cn("font-bold", (perf.winRate || 0) >= 60 ? "text-profit" : (perf.winRate || 0) >= 50 ? "text-yellow-400" : "text-loss")}>
                      {perf.winRate}%
                    </div>
                  </div>
                </div>

                {isEnabled && (
                  <div className="mt-2 px-2 py-1 rounded-lg bg-primary/10 border border-primary/20">
                    <span className="text-xs text-primary font-medium">✓ Aktif</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Oluşturulan Stratejiler */}
      {customStrategies.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold mb-3 text-muted-foreground">Oluşturulan Stratejiler ({customStrategies.length})</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {customStrategies.map(strategy => {
              const isEnabled = enabled.includes(strategy.id);

              return (
                <div
                  key={strategy.id}
                  className={cn(
                    "bg-card border rounded-lg p-3 transition-all flex flex-col",
                    isEnabled ? "border-primary/30 ring-1 ring-primary/10" : "border-border"
                  )}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-start gap-2 flex-1 min-w-0">
                      <div className="text-lg flex-shrink-0">{strategy.icon}</div>
                      <div className="min-w-0 flex-1">
                        <h3 className="text-xs font-bold truncate">{strategy.name}</h3>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{strategy.desc}</p>
                      </div>
                    </div>
                    <Switch
                      checked={isEnabled}
                      onCheckedChange={() => toggleStrategy(strategy.id)}
                      className="flex-shrink-0"
                    />
                  </div>

                  {/* Custom strateji piyasa uyum puanı */}
                  {currentMode && (
                    <CustomStrategyFitBadge strategy={strategy.strategy} currentMode={currentMode} />
                  )}

                  {strategy.strategy?.backtest && (
                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-border text-xs">
                      <div>
                        <div className="text-muted-foreground">İşlemler</div>
                        <div className="font-bold">{strategy.strategy.backtest.trades || 0}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Kazanan</div>
                        <div className="font-bold text-profit">{strategy.strategy.backtest.wins || 0}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Oran</div>
                        <div className="font-bold">{strategy.strategy.backtest.winRate}%</div>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-border">
                    {isEnabled && (
                      <div className="px-1.5 py-0.5 rounded-lg bg-primary/10 border border-primary/20">
                        <span className="text-xs text-primary font-medium">✓ Aktif</span>
                      </div>
                    )}
                    {strategy.is_db && (
                      <Button
                        onClick={() => deleteCustomStrategy(strategy.id)}
                        variant="ghost"
                        size="sm"
                        className="w-fit h-fit p-1 text-destructive hover:text-destructive ml-auto"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Özet */}
      <div className="mt-6 bg-secondary border border-border rounded-xl p-4">
        <div className="flex items-start gap-3">
          <BarChart3 className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
          <div className="text-sm">
            <div className="font-semibold text-foreground mb-1">
              Seçili Stratejiler: <span className="text-primary">{enabled.length}/{6 + customStrategies.length}</span>
            </div>
            <div className="text-xs text-muted-foreground space-y-1">
              {enabled.length === 0 ? (
                <p>En az 1 strateji seçiniz</p>
              ) : (
                <>
                  <p>Seçili: {enabled.join(', ')}</p>
                  <p className="mt-2">Motor başlatıldığında sadece seçili stratejiler çalışacak. Ensemble motor en iyi sinyali seçer.</p>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}