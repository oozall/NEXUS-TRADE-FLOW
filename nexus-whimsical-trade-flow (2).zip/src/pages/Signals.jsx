import React, { useState } from 'react';
import { useEngine } from '@/lib/engineContext';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, Zap, ChevronDown, ChevronUp, Shield, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

function ConfidenceBadge({ score }) {
  const color = score >= 80 ? 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20'
    : score >= 65 ? 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20'
    : score >= 50 ? 'text-orange-400 bg-orange-400/10 border-orange-400/20'
    : 'text-red-400 bg-red-400/10 border-red-400/20';
  return (
    <span className={cn("px-2 py-0.5 rounded-full border text-xs font-bold font-mono", color)}>
      {score}%
    </span>
  );
}

function RiskBadge({ level }) {
  const map = {
    'DÜŞÜK': 'text-emerald-400 bg-emerald-400/10',
    'ORTA': 'text-yellow-400 bg-yellow-400/10',
    'YÜKSEK': 'text-red-400 bg-red-400/10',
  };
  return (
    <span className={cn("px-2 py-0.5 rounded-md text-xs font-medium", map[level] || 'text-muted-foreground bg-muted')}>
      {level || '—'}
    </span>
  );
}

function ScoreBar({ label, value, color = 'bg-primary' }) {
  return (
    <div className="flex items-center gap-2">
      <div className="text-xs text-muted-foreground w-20 shrink-0">{label}</div>
      <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
        <div className={cn("h-full rounded-full", color)} style={{ width: `${Math.min(100, value || 0)}%` }} />
      </div>
      <div className="text-xs font-mono text-foreground w-8 text-right">{Math.round(value || 0)}</div>
    </div>
  );
}

function SignalRow({ s }) {
  const [expanded, setExpanded] = useState(false);
  const isLong = s.direction === 'LONG';
  const hasMultiLayer = !!s.scoreBreakdown;

  return (
    <>
      <tr
        className={cn("border-b border-border/50 hover:bg-secondary/30 transition-colors cursor-pointer", expanded && "bg-secondary/20")}
        onClick={() => setExpanded(e => !e)}
      >
        <td className="px-3 py-2.5 font-bold text-sm">{s.symbol?.replace('USDT', '')}</td>
        <td className="px-3 py-2.5">
          <div className={cn("flex items-center gap-1 text-xs font-bold", isLong ? "text-primary" : "text-red-400")}>
            {isLong ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {isLong ? 'UZUN' : 'KISA'}
          </div>
        </td>
        <td className="px-3 py-2.5 text-xs text-muted-foreground">{s.strategy?.replace(/_/g, ' ')}</td>
        <td className="px-3 py-2.5 text-xs">{s.timeframe}</td>
        <td className="px-3 py-2.5"><ConfidenceBadge score={s.confidence} /></td>
        <td className="px-3 py-2.5 font-mono text-xs">${s.entry?.toFixed(4)}</td>
        <td className="px-3 py-2.5 font-mono text-xs text-red-400">${s.stop?.toFixed(4)}</td>
        <td className="px-3 py-2.5 font-mono text-xs text-primary">${s.target?.toFixed(4)}</td>
        <td className="px-3 py-2.5 text-xs font-mono">{s.riskReward?.toFixed(1)}</td>
        <td className="px-3 py-2.5 text-xs">
          <span className="text-muted-foreground">{s.regimeLabel || s.regime?.replace(/_/g, ' ')}</span>
        </td>
        <td className="px-3 py-2.5"><RiskBadge level={s.riskLevel} /></td>
        <td className="px-3 py-2.5 text-xs text-muted-foreground">
          {s.signal_time ? formatDistanceToNow(new Date(s.signal_time), { addSuffix: true }) : 'şimdi'}
        </td>
        <td className="px-3 py-2.5 text-muted-foreground">
          {hasMultiLayer && (expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />)}
        </td>
      </tr>

      {expanded && hasMultiLayer && (
        <tr className="bg-secondary/10 border-b border-border/50">
          <td colSpan={13} className="px-4 py-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

              {/* Skor Dağılımı */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-foreground mb-2">Skor Dağılımı</div>
                <ScoreBar label="Rejim" value={s.scoreBreakdown?.regime} color="bg-blue-500" />
                <ScoreBar label="Strateji" value={s.scoreBreakdown?.strategy} color="bg-primary" />
                <ScoreBar label="Zaman Dilimi" value={s.scoreBreakdown?.timeframe} color="bg-yellow-500" />
                <ScoreBar label="Coin Gücü" value={s.scoreBreakdown?.coin} color="bg-purple-500" />
                <ScoreBar label="Volatilite" value={s.scoreBreakdown?.volatility} color="bg-orange-500" />
                <div className="border-t border-border/50 pt-2 mt-1">
                  <ScoreBar label="Final" value={s.scoreBreakdown?.final} color="bg-emerald-500" />
                </div>
                {s.scoreBreakdown?.instabilityPenalty < 1 && (
                  <div className="flex items-center gap-1 text-xs text-warning mt-1">
                    <AlertTriangle className="w-3 h-3" />
                    Rejim penaltısı: x{s.scoreBreakdown.instabilityPenalty}
                  </div>
                )}
              </div>

              {/* Strateji Uyumu */}
              <div>
                <div className="text-xs font-semibold text-foreground mb-2">Strateji Analizi</div>
                {s.agreeingStrategies?.length > 0 && (
                  <div className="mb-2">
                    <div className="text-xs text-muted-foreground mb-1">Onaylayan ({s.agreementRatio}%)</div>
                    <div className="flex flex-wrap gap-1">
                      {s.agreeingStrategies.map(st => (
                        <span key={st} className="flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs">
                          <CheckCircle2 className="w-2.5 h-2.5" />{st.replace(/_/g, ' ')}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                {s.conflictingStrategies?.length > 0 && (
                  <div className="mb-2">
                    <div className="text-xs text-muted-foreground mb-1">Çelişen</div>
                    <div className="flex flex-wrap gap-1">
                      {s.conflictingStrategies.map(st => (
                        <span key={st} className="flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-red-400/10 text-red-400 text-xs">
                          <AlertTriangle className="w-2.5 h-2.5" />{st.replace(/_/g, ' ')}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                {s.confirmingTimeframes?.length > 0 && (
                  <div className="mt-2">
                    <div className="text-xs text-muted-foreground mb-1">Onaylayan TF'ler</div>
                    <div className="flex flex-wrap gap-1">
                      {s.confirmingTimeframes.map(tf => (
                        <span key={tf} className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-mono">{tf}</span>
                      ))}
                      {s.rejectingTimeframes?.map(tf => (
                        <span key={tf} className="px-2 py-0.5 rounded-md bg-red-400/10 text-red-400 text-xs font-mono">{tf}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Açıklama & Coin Gücü */}
              <div>
                <div className="text-xs font-semibold text-foreground mb-2">Analiz Özeti</div>
                {s.explanation && (
                  <p className="text-xs text-muted-foreground leading-relaxed mb-3">{s.explanation}</p>
                )}
                {s.coinDetails && (
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {[
                      ['Coin Getiri', `${s.coinDetails.symbolReturn}%`],
                      ['BTC Getiri', `${s.coinDetails.btcReturn}%`],
                      ['Alpha', `${s.coinDetails.alpha}%`],
                      ['Piyasa Uyumu', s.coinDetails.sameDirectionBTC ? '✓ Uyumlu' : '✗ Aykırı'],
                    ].map(([l, v]) => (
                      <div key={l} className="bg-secondary rounded p-2">
                        <div className="text-muted-foreground mb-0.5">{l}</div>
                        <div className="font-mono font-medium">{v}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </td>
        </tr>
      )}
    </>
  );
}

export default function Signals() {
  const { recentSignals } = useEngine();
  const [filter, setFilter] = useState('all');
  const [minConf, setMinConf] = useState(0);

  const filtered = recentSignals.filter(s => {
    if (filter === 'long') return s.direction === 'LONG';
    if (filter === 'short') return s.direction === 'SHORT';
    if (filter === 'high') return s.confidence >= 75;
    return true;
  }).filter(s => (s.confidence || 0) >= minConf);

  const longCount = recentSignals.filter(s => s.direction === 'LONG').length;
  const shortCount = recentSignals.filter(s => s.direction === 'SHORT').length;
  const highConf = recentSignals.filter(s => s.confidence >= 75).length;
  const avgConf = recentSignals.length > 0
    ? (recentSignals.reduce((s, r) => s + (r.confidence || 0), 0) / recentSignals.length).toFixed(0)
    : 0;

  return (
    <div className="p-4 lg:p-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl font-bold">Sinyaller</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Çok katmanlı sinyal motoru — satıra tıkla → detay</p>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Shield className="w-4 h-4 text-primary" />
          <span className="font-bold text-primary">{avgConf}% ort. güven</span>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        {[
          { label: 'Toplam', value: recentSignals.length, color: '' },
          { label: 'Uzun', value: longCount, color: 'text-profit' },
          { label: 'Kısa', value: shortCount, color: 'text-loss' },
          { label: 'Yüksek Güven (≥75)', value: highConf, color: 'text-primary' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-xl p-4 text-center">
            <div className={cn("text-2xl font-bold font-mono", s.color)}>{s.value}</div>
            <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="flex gap-1 bg-secondary border border-border rounded-lg p-1">
          {[['all', 'Tümü'], ['long', 'Uzun'], ['short', 'Kısa'], ['high', '≥75%']].map(([f, label]) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "text-sm px-3 py-1.5 rounded-md font-medium transition-all",
                filter === f ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Min. güven:</span>
          <input
            type="range" min={0} max={90} step={5} value={minConf}
            onChange={e => setMinConf(Number(e.target.value))}
            className="w-24 accent-primary"
          />
          <span className="font-mono text-foreground">{minConf}%</span>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary/50">
                {['Sembol', 'Yön', 'Baskın Strateji', 'TF', 'Güven', 'Giriş', 'Stop', 'Hedef', 'R:R', 'Rejim', 'Risk', 'Zaman', ''].map(h => (
                  <th key={h} className="text-left text-xs font-medium text-muted-foreground px-3 py-3 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={13} className="text-center text-muted-foreground py-12">
                  <Zap className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  Henüz sinyal yok. Sinyaller oluşturmak için motoru başlatın.
                </td></tr>
              ) : (
                filtered.map(s => <SignalRow key={s.id || s.signal_time} s={s} />)
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}