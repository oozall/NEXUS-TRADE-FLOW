import React, { useState, useEffect } from 'react';
import { useEngine } from '@/lib/engineContext';
import { useModeScoringContext } from '@/lib/modeScoringContext';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Play, Square, Activity, TrendingUp, BarChart2, Zap, AlertTriangle } from 'lucide-react';
import StatCard from '@/components/dashboard/StatCard';
import AggressionSlider from '@/components/dashboard/AggressionSlider';
import PaperBalanceControl from '@/components/dashboard/PaperBalanceControl';
import PositionCard from '@/components/dashboard/PositionCard';
import SignalRow from '@/components/dashboard/SignalRow';
import SystemHealth from '@/components/dashboard/SystemHealth';
import MarketTicker from '@/components/dashboard/MarketTicker';
import RiskBarIndicator from '@/components/dashboard/RiskBarIndicator';
import { cn } from '@/lib/utils';

export default function Dashboard() {
  const {
    engineStatus, openPositions, recentSignals, totalPnl, unrealizedPnl,
    startEngine, stopEngine, setAggressionLevel, setMode, closePosition, apiConfig, isLoadingConfig, 
    adaptiveMode, setAdaptiveMode, paperBalance, setPaperBalance, extraSettings, onSettingsChange
  } = useEngine();
  const { currentMode, latestEvaluation, simulatedRegime } = useModeScoringContext();
  const [starting, setStarting] = useState(false);
  const [totalLeverage, setTotalLeverage] = useState(0);
  const [liquidationRisk, setLiquidationRisk] = useState(0);

  // Her saniye açık pozisyonlardan risk metriklerini hesapla
  useEffect(() => {
    const interval = setInterval(() => {
      if (openPositions.length === 0) {
        setTotalLeverage(0);
        setLiquidationRisk(0);
        return;
      }

      const avgLeverage = openPositions.reduce((sum, p) => sum + (p.leverage || 1), 0) / openPositions.length;
      setTotalLeverage(avgLeverage);

      const totalNegativePnl = openPositions.reduce((sum, p) => {
        const pnl = p.unrealized_pnl || 0;
        return sum + (pnl < 0 ? Math.abs(pnl) : 0);
      }, 0);
      const estimatedCapital = paperBalance || 10000;
      const risk = (totalNegativePnl / estimatedCapital) * 100;
      setLiquidationRisk(Math.min(risk, 100));
    }, 1000);

    return () => clearInterval(interval);
  }, [openPositions, paperBalance]);

  const handleToggle = async () => {
    if (engineStatus.running) {
      stopEngine();
    } else {
      setStarting(true);
      if (currentMode) setAdaptiveMode(currentMode);
      await startEngine().finally(() => setStarting(false));
    }
  };

  const totalTrades = engineStatus.tradesExecuted;
  const winCount = 0; // calculated from closed positions
  const winRate = totalTrades > 0 ? (winCount / totalTrades * 100).toFixed(0) : '--';

  return (
    <div className="flex flex-col h-full">
      <MarketTicker />

      <div className="flex-1 p-4 lg:p-6 space-y-5 overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">Kontrol Paneli</h1>
            <p className="text-sm text-muted-foreground flex items-center gap-2 flex-wrap">
              {engineStatus.mode === 'paper' ? 'Kağıt Trading' : engineStatus.mode === 'live' ? 'Canlı Trading' : 'Backtest'} Modu
              {currentMode && (
                <Link to="/adaptive-mode" className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-semibold hover:bg-primary/20 transition-colors">
                  🤖 {currentMode.replace(/_/g, ' ')}
                  {latestEvaluation?.finalScores?.[currentMode] && (
                    <span className="opacity-70">· {latestEvaluation.finalScores[currentMode].toFixed(0)}p</span>
                  )}
                </Link>
              )}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {/* Mode selector */}
            <div className="flex bg-secondary border border-border rounded-lg p-1 gap-1">
              {[['paper', 'Kağıt'], ['live', 'Canlı']].map(([m, label]) => (
                <button
                  key={m}
                  onClick={() => !engineStatus.running && setMode(m)}
                  disabled={engineStatus.running}
                  className={cn(
                    "text-xs px-3 py-1.5 rounded-md font-medium transition-all",
                    engineStatus.mode === m
                      ? m === 'live' ? "bg-red-500/20 text-red-400 border border-red-500/30" : "bg-primary/10 text-primary border border-primary/20"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {m === 'live' && <span className="mr-1">⚠</span>}
                  {label}
                </button>
              ))}
            </div>

            <Button
              onClick={handleToggle}
              disabled={starting || isLoadingConfig}
              size="sm"
              className={cn(
                "gap-2 font-semibold",
                engineStatus.running
                  ? "bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20"
                  : "bg-primary text-primary-foreground hover:bg-primary/90"
              )}
              variant={engineStatus.running ? "outline" : "default"}
            >
              {engineStatus.running
                ? <><Square className="w-3.5 h-3.5" /> Motoru Durdur</>
                : starting
                  ? <><Activity className="w-3.5 h-3.5 animate-pulse" /> Başlatılıyor...</>
                  : <><Play className="w-3.5 h-3.5" /> Motoru Başlat</>
              }
            </Button>
          </div>
        </div>

        {/* Warning for live mode without API */}
        {engineStatus.mode === 'live' && !apiConfig && (
          <div className="flex items-center gap-3 bg-warning/10 border border-warning/20 rounded-xl px-4 py-3 text-sm">
            <AlertTriangle className="w-4 h-4 text-warning flex-shrink-0" />
            <span className="text-warning">Canlı mod API anahtarları gerektirir. Binance hesabınızı bağlamak için Ayarlar'a gidin.</span>
          </div>
        )}

        {/* Stats row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatCard
            title="Toplam P&L"
            value={`${totalPnl >= 0 ? '+' : ''}$${totalPnl.toFixed(2)}`}
            subtitle="Kapanan tüm işlemler"
            icon={BarChart2}
            accent
          />
          <StatCard
            title="Gerçekleşmemiş"
            value={`${unrealizedPnl >= 0 ? '+' : ''}$${unrealizedPnl.toFixed(2)}`}
            subtitle="Açık pozisyonlar"
            icon={Activity}
          />
          <StatCard
            title="Açık Pozisyonlar"
            value={openPositions.length}
            subtitle={`Max ${extraSettings?.maxPositions ?? (engineStatus.aggrLevel <= 3 ? 2 : engineStatus.aggrLevel <= 6 ? 5 : 20)}`}
            icon={TrendingUp}
          />
          <StatCard
            title="Bugünün Sinyalleri"
            value={engineStatus.signalsToday}
            subtitle="Üretilen sinyaller"
            icon={Zap}
          />
        </div>

        {/* Main grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Left - Controls + Health + Risk Gauge */}
          <div className="space-y-4">
            <AggressionSlider
              value={engineStatus.aggrLevel}
              onChange={setAggressionLevel}
              disabled={false}
              extraSettings={extraSettings}
              onSettingsChange={onSettingsChange}
            />
            {engineStatus.mode === 'paper' && (
              <PaperBalanceControl
                balance={paperBalance}
                onBalanceChange={setPaperBalance}
                disabled={engineStatus.running}
              />
            )}
            <RiskBarIndicator 
              totalLeverage={totalLeverage}
              liquidationRisk={liquidationRisk}
              openPositions={openPositions.length}
            />
            <SystemHealth />
          </div>

          {/* Center - Open Positions */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold">Open Positions <span className="text-muted-foreground">({openPositions.length})</span></h2>
            </div>
            {openPositions.length === 0 ? (
              <div className="bg-card border border-border rounded-xl p-8 text-center">
                <Activity className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">No open positions</p>
                <p className="text-xs text-muted-foreground mt-1">Start the engine to begin scanning</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                {openPositions.map(p => (
                  <PositionCard key={p.id} position={p} onClose={closePosition} />
                ))}
              </div>
            )}
          </div>

          {/* Right - Recent Signals */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold">Recent Signals</h2>
              <span className="text-xs text-muted-foreground">{recentSignals.length} total</span>
            </div>
            <div className="bg-card border border-border rounded-xl px-4">
              {recentSignals.length === 0 ? (
                <div className="py-8 text-center">
                  <Zap className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">No signals yet</p>
                </div>
              ) : (
                <div className="max-h-[480px] overflow-y-auto">
                  {recentSignals.slice(0, 20).map(s => (
                    <SignalRow key={s.id} signal={s} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}