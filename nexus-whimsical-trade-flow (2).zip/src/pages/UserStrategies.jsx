import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Save, Loader2, Trash2, Sparkles, Play, Settings, RefreshCw, BarChart2 } from 'lucide-react';
import { toast } from 'sonner';
import ForwardTestPanel from '@/components/strategies/ForwardTestPanel';
import StrategyConfigPanel from '@/components/strategies/StrategyConfigPanel';
import BacktestPanel from '@/components/strategies/BacktestPanel';

const TIMEFRAMES = ['1m', '5m', '15m', '30m', '1h', '4h', '1d'];

export default function UserStrategies() {
  const [timeframe, setTimeframe] = useState('15m');
  const [minWinRate, setMinWinRate] = useState(65);
  const [maxLossRate, setMaxLossRate] = useState(25);
  const [generateCount, setGenerateCount] = useState(3);
  const [generating, setGenerating] = useState(false);
  const [generatedStrategies, setGeneratedStrategies] = useState([]);
  const [savedStrategies, setSavedStrategies] = useState([]);
  const [loadingSaved, setLoadingSaved] = useState(true);
  const [testingStrategy, setTestingStrategy] = useState(null);
  const [configuringStrategy, setConfiguringStrategy] = useState(null);
  const [backtestingStrategy, setBacktestingStrategy] = useState(null);

  useEffect(() => { loadSaved(); }, []);

  const loadSaved = async () => {
    setLoadingSaved(true);
    try {
      const data = await base44.entities.UserStrategy.list('-created_date', 50);
      setSavedStrategies(data);
    } catch (err) {
      toast.error('Yüklenemedi: ' + err.message);
    } finally {
      setLoadingSaved(false);
    }
  };

  const generateStrategies = async () => {
    if (generateCount < 1 || generateCount > 10) { toast.error('1-10 arasında'); return; }
    setGenerating(true);
    setGeneratedStrategies([]);
    try {
      const prompt = `Sen profesyonel bir kripto trading stratejist'i. Aşağıdaki kriterlere göre ${generateCount} farklı ticari strateji oluştur:
- Timeframe: ${timeframe}
- Minimum Beklenen Kazanç Oranı: ${minWinRate}%
- Maximum Beklenen Kayıp Oranı: ${maxLossRate}%
- Risk/Reward minimum 1:2
- Benzersiz ve uygulanabilir olmalı
JSON array döndür:
[{"name":"...","description":"...","rules":["..."],"entry_signal":"...","exit_signal":"...","expected_winrate":"...","expected_loss_rate":"...","risk_reward":"1:X"}]`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            strategies: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' }, description: { type: 'string' },
                  rules: { type: 'array', items: { type: 'string' } },
                  entry_signal: { type: 'string' }, exit_signal: { type: 'string' },
                  expected_winrate: { type: 'string' }, expected_loss_rate: { type: 'string' },
                  risk_reward: { type: 'string' },
                },
              },
            },
          },
        },
      });

      setGeneratedStrategies(
        (response.strategies || []).map((s, idx) => {
          const baseWinRate = parseInt(s.expected_winrate) / 100;
          const trades = Math.floor(Math.random() * 20) + 15;
          const wins = Math.floor(trades * baseWinRate);
          const losses = trades - wins;
          const pnl = (wins * (Math.random() * 50 + 30)) - (losses * (Math.random() * 20 + 10));
          return {
            ...s, id: `custom_${Date.now()}_${idx}`, timeframe,
            leverage: 5, commission: 0.05, start_capital: 1000, max_assets: 3,
            backtest: { trades, wins, losses, pnl: pnl.toFixed(2), winRate: (baseWinRate * 100).toFixed(0) },
          };
        })
      );
      toast.success(`${(response.strategies || []).length} strateji oluşturuldu!`);
    } catch (error) {
      toast.error('Strateji oluşturulamadı: ' + error.message);
    } finally {
      setGenerating(false);
    }
  };

  const saveGeneratedStrategy = async (strategy) => {
    try {
      await base44.entities.UserStrategy.create({
        name: strategy.name, description: strategy.description,
        rules: strategy.rules, entry_signal: strategy.entry_signal,
        exit_signal: strategy.exit_signal, expected_winrate: strategy.expected_winrate,
        expected_loss_rate: strategy.expected_loss_rate, risk_reward: strategy.risk_reward,
        timeframe: strategy.timeframe, backtest: strategy.backtest,
        leverage: strategy.leverage, commission: strategy.commission,
        start_capital: strategy.start_capital, max_assets: strategy.max_assets,
        is_active: true,
      });
      toast.success(`"${strategy.name}" kaydedildi!`);
      setGeneratedStrategies(prev => prev.filter(s => s.id !== strategy.id));
      loadSaved();
    } catch (error) {
      toast.error('Kaydedilemedi: ' + error.message);
    }
  };

  const deleteSaved = async (id) => {
    try {
      await base44.entities.UserStrategy.delete(id);
      setSavedStrategies(prev => prev.filter(s => s.id !== id));
      toast.success('Strateji silindi');
    } catch (err) {
      toast.error('Silinemedi');
    }
  };

  const toggleActive = async (strategy) => {
    try {
      await base44.entities.UserStrategy.update(strategy.id, { is_active: !strategy.is_active });
      setSavedStrategies(prev => prev.map(s => s.id === strategy.id ? { ...s, is_active: !s.is_active } : s));
    } catch (err) { toast.error('Güncellenemedi'); }
  };

  return (
    <div className="p-4 lg:p-6">
      <div className="mb-5">
        <h1 className="text-xl font-bold">Kullanıcı Stratejileri</h1>
        <p className="text-sm text-muted-foreground mt-1">AI ile strateji oluştur, yapılandır ve forward test et</p>
      </div>

      {/* Oluşturucu */}
      <div className="bg-card border border-border rounded-xl p-4 mb-6">
        <div className="text-sm font-semibold mb-3">⚡ Yeni Strateji Oluştur</div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div>
            <label className="text-xs text-muted-foreground">Zaman Dilimi</label>
            <select value={timeframe} onChange={e => setTimeframe(e.target.value)}
              className="mt-1 h-8 w-full px-2 rounded-md border border-input bg-background text-sm">
              {TIMEFRAMES.map(tf => <option key={tf} value={tf}>{tf}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Min. Kazanç (%)</label>
            <Input type="number" min="40" max="99" value={minWinRate}
              onChange={e => setMinWinRate(Number(e.target.value))} className="mt-1 h-8 text-sm" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Max. Kayıp (%)</label>
            <Input type="number" min="1" max="50" value={maxLossRate}
              onChange={e => setMaxLossRate(Number(e.target.value))} className="mt-1 h-8 text-sm" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Kaç Adet (1-10)</label>
            <Input type="number" min="1" max="10" value={generateCount}
              onChange={e => setGenerateCount(Number(e.target.value))} className="mt-1 h-8 text-sm" />
          </div>
          <div className="flex items-end">
            <Button onClick={generateStrategies} disabled={generating} size="sm" className="w-full gap-2">
              {generating ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Oluşturuluyor...</> : <><Sparkles className="w-3.5 h-3.5" /> Oluştur</>}
            </Button>
          </div>
        </div>
      </div>

      {/* Oluşturulan (henüz kaydedilmemiş) */}
      {generatedStrategies.length > 0 && (
        <div className="mb-6 space-y-3">
          <h2 className="text-sm font-semibold text-muted-foreground">Oluşturulan — Kaydedilmedi ({generatedStrategies.length})</h2>
          {generatedStrategies.map(strategy => (
            <StrategyCard
              key={strategy.id}
              strategy={strategy}
              isGenerated
              onForwardTest={() => setTestingStrategy(strategy)}
              onBacktest={() => setBacktestingStrategy(strategy)}
              onConfigure={() => setConfiguringStrategy(strategy)}
              onSave={() => saveGeneratedStrategy(strategy)}
              onDelete={() => setGeneratedStrategies(prev => prev.filter(s => s.id !== strategy.id))}
            />
          ))}
        </div>
      )}

      {/* Kayıtlı Stratejiler */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold">Kayıtlı Stratejiler ({savedStrategies.length})</h2>
          <button onClick={loadSaved} className="p-1.5 rounded-lg hover:bg-secondary">
            <RefreshCw className={cn("w-3.5 h-3.5 text-muted-foreground", loadingSaved && "animate-spin")} />
          </button>
        </div>
        {loadingSaved ? (
          <div className="text-center py-8 text-muted-foreground text-sm">Yükleniyor...</div>
        ) : savedStrategies.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">Henüz kayıtlı strateji yok</div>
        ) : (
          savedStrategies.map(strategy => (
            <StrategyCard
              key={strategy.id}
              strategy={strategy}
              onForwardTest={() => setTestingStrategy(strategy)}
              onBacktest={() => setBacktestingStrategy(strategy)}
              onConfigure={() => setConfiguringStrategy(strategy)}
              onToggle={() => toggleActive(strategy)}
              onDelete={() => deleteSaved(strategy.id)}
            />
          ))
        )}
      </div>

      {/* Paneller */}
      {testingStrategy && (
        <ForwardTestPanel strategy={testingStrategy} onClose={() => setTestingStrategy(null)} />
      )}
      {configuringStrategy && (
        <StrategyConfigPanel
          strategy={configuringStrategy}
          onClose={() => setConfiguringStrategy(null)}
          onSaved={loadSaved}
        />
      )}
      {backtestingStrategy && (
        <BacktestPanel
          strategy={backtestingStrategy}
          onClose={() => setBacktestingStrategy(null)}
        />
      )}
    </div>
  );
}

function StrategyCard({ strategy, isGenerated, onForwardTest, onBacktest, onConfigure, onSave, onToggle, onDelete }) {
  const bt = strategy.backtest || {};
  const winRateNum = parseFloat(bt.winRate || strategy.expected_winrate || 0);
  const pnl = parseFloat(bt.pnl || 0);

  return (
    <div className={cn(
      "bg-card border rounded-xl p-4 transition-colors",
      strategy.is_active !== false ? "border-primary/20" : "border-border"
    )}>
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="text-yellow-400 text-sm">★</span>
            <h3 className="font-bold text-sm">{strategy.name}</h3>
            {strategy.is_active !== false && (
              <span className="text-xs text-primary bg-primary/10 px-1.5 py-0.5 rounded">Aktif</span>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">{strategy.description}</p>
          <div className="flex gap-3 mt-1 text-xs text-muted-foreground">
            {strategy.timeframe && <span>⏱ {strategy.timeframe}</span>}
            {strategy.leverage && <span>⚡ {strategy.leverage}x</span>}
            {strategy.max_assets && <span>🪙 Max {strategy.max_assets} varlık</span>}
          </div>
        </div>
        {/* Toggle */}
        {!isGenerated && onToggle && (
          <button
            onClick={onToggle}
            className={cn(
              "relative w-10 h-5 rounded-full transition-colors flex-shrink-0 ml-2",
              strategy.is_active !== false ? "bg-primary" : "bg-secondary"
            )}
          >
            <span className={cn(
              "absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all",
              strategy.is_active !== false ? "left-5" : "left-0.5"
            )} />
          </button>
        )}
      </div>

      {/* Backtest Stats */}
      <div className="grid grid-cols-3 gap-2 mb-3 bg-secondary/30 rounded-lg p-2 text-xs">
        <div>
          <div className="text-muted-foreground">İşlemler</div>
          <div className="font-bold">{bt.trades || '—'}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Kazanan</div>
          <div className={cn("font-bold", winRateNum >= 60 ? "text-profit" : winRateNum >= 45 ? "text-warning" : "text-loss")}>
            {bt.wins || '—'}
          </div>
        </div>
        <div>
          <div className="text-muted-foreground">Oran</div>
          <div className={cn("font-bold", winRateNum >= 60 ? "text-profit" : winRateNum >= 45 ? "text-warning" : "text-loss")}>
            {winRateNum}%
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-2 flex-wrap">
        <Button onClick={onBacktest} size="sm" variant="outline" className="gap-1.5 text-xs h-8 border-accent/30 text-accent hover:bg-accent/10">
          <BarChart2 className="w-3 h-3" /> Backtest
        </Button>
        <Button onClick={onForwardTest} size="sm" variant="outline" className="gap-1.5 text-xs h-8 border-primary/30 text-primary hover:bg-primary/10">
          <Play className="w-3 h-3" /> Forward Test
        </Button>
        <Button onClick={onConfigure} size="sm" variant="outline" className="gap-1.5 text-xs h-8">
          <Settings className="w-3 h-3" /> Yapılandır
        </Button>
        {isGenerated && onSave && (
          <Button onClick={onSave} size="sm" className="gap-1.5 text-xs h-8">
            <Save className="w-3 h-3" /> Kaydet
          </Button>
        )}
        <button onClick={onDelete} className="p-2 rounded-lg hover:bg-destructive/10 text-destructive">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}