import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, Activity, TrendingUp, BarChart2, 
  Settings, Bell, Wifi, WifiOff, Shield, ChevronLeft, ChevronRight, Menu, X, Zap
} from 'lucide-react';
import { useEngine } from '@/lib/engineContext';
import { cn } from '@/lib/utils';

const navItems = [
  { path: '/', icon: LayoutDashboard, label: 'Kontrol Paneli' },
  { path: '/adaptive-mode', icon: Zap, label: 'Adaptif Mod', highlight: true },
  { path: '/positions', icon: Activity, label: 'Pozisyonlar' },
  { path: '/signals', icon: TrendingUp, label: 'Sinyaller' },
  { path: '/market', icon: BarChart2, label: 'Pazar' },
  { path: '/performance', icon: BarChart2, label: 'Performans' },
  { path: '/strategies', icon: Settings, label: 'Stratejiler' },
  { path: '/user-strategies', icon: TrendingUp, label: 'Kullanıcı Stratejileri' },
  { path: '/settings', icon: Settings, label: 'Ayarlar' },
];

export default function AppLayout({ children }) {
  const location = useLocation();
  const { engineStatus, apiConfig } = useEngine();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:relative z-50 h-full flex flex-col bg-sidebar border-r border-sidebar-border transition-all duration-300",
        collapsed ? "w-16" : "w-56",
        mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Logo */}
        <div className={cn("flex items-center gap-3 px-4 py-4 border-b border-sidebar-border", collapsed && "justify-center px-2")}>
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center flex-shrink-0">
            <span className="text-primary-foreground font-bold text-sm">FX</span>
            </div>
            {!collapsed && (
            <div>
              <div className="font-bold text-sm text-foreground">FuturesX</div>
              <div className="text-xs text-muted-foreground">Otomatik İşlem</div>
            </div>
            )}
        </div>

        {/* Engine status badge */}
        {!collapsed && (
          <div className="mx-3 mt-3 px-3 py-2 rounded-lg bg-secondary border border-border">
            <div className="flex items-center gap-2">
              <div className={cn("w-2 h-2 rounded-full", engineStatus.running ? "bg-primary pulse-live" : "bg-muted-foreground")} />
              <span className="text-xs font-medium">{engineStatus.running ? 'Motor Çalışıyor' : 'Motor Durduruldu'}</span>
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              Mod: <span className="text-foreground capitalize">{engineStatus.mode === 'paper' ? 'Kağıt' : engineStatus.mode === 'live' ? 'Canlı' : engineStatus.mode}</span>
            </div>
          </div>
        )}

        {/* Nav */}
        <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
          {navItems.map(item => {
            const active = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all",
                  active
                    ? "bg-primary/10 text-primary font-medium border border-primary/20"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-foreground",
                  item.highlight && !active && "text-yellow-400 hover:text-yellow-300",
                  collapsed && "justify-center px-2"
                )}
              >
                <item.icon className="w-4 h-4 flex-shrink-0" />
                {!collapsed && (
                  <>
                    <span>{item.label}</span>
                    {item.highlight && <span className="ml-auto text-xs bg-yellow-500/20 px-1.5 py-0.5 rounded text-yellow-400 font-semibold">YENİ</span>}
                  </>
                )}
              </Link>
            );
          })}
        </nav>

        {/* API status */}
        <div className={cn("px-3 pb-4 border-t border-sidebar-border pt-3", collapsed && "px-2")}>
          <div className={cn("flex items-center gap-2 text-xs", collapsed && "justify-center")}>
            {apiConfig?.status === 'connected'
              ? <><Wifi className="w-3.5 h-3.5 text-primary" />{!collapsed && <span className="text-primary">API Connected</span>}</>
              : <><WifiOff className="w-3.5 h-3.5 text-muted-foreground" />{!collapsed && <span className="text-muted-foreground">No API Key</span>}</>
            }
          </div>
        </div>

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-secondary border border-border rounded-full items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          {collapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
        </button>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center justify-between px-4 py-3 border-b border-border bg-card flex-shrink-0">
          <button className="lg:hidden p-1.5 rounded-md hover:bg-secondary" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          
          <div className="flex items-center gap-3 ml-auto">
            {engineStatus.safeMode && (
              <div className="flex items-center gap-1.5 text-xs text-warning bg-warning/10 border border-warning/20 px-2.5 py-1 rounded-full">
                <Shield className="w-3 h-3" />
                <span>Safe Mode</span>
              </div>
            )}
            <div className="text-xs text-muted-foreground">
              Saldı: <span className="text-foreground font-mono font-medium">{engineStatus.aggrLevel}/25</span>
            </div>
            <div className={cn(
              "flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border",
              engineStatus.running
                ? "text-primary bg-primary/10 border-primary/20"
                : "text-muted-foreground bg-secondary border-border"
            )}>
              <div className={cn("w-1.5 h-1.5 rounded-full", engineStatus.running ? "bg-primary pulse-live" : "bg-muted-foreground")} />
              {engineStatus.running ? 'ÇALIŞIYOR' : 'DURDURULDU'}
            </div>
          </div>
        </header>

        {/* Page content */}
        <div className="flex-1 overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  );
}