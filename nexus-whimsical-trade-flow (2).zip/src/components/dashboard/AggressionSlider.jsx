import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { Slider } from '@/components/ui/slider';
import { Settings, X, Check } from 'lucide-react';

// 1-25 arasında seviye etiketleri
function getLevelMeta(v) {
  const t = (v - 1) / 24; // 0→1
  const lerp = (a, b) => a + (b - a) * t;

  let label, color, desc;
  if (v <= 3)       { label = 'Süper Güvenli';     color = 'text-blue-300';    desc = 'Max koruma, çok nadir işlem'; }
  else if (v <= 5)  { label = 'Savunmacı';          color = 'text-blue-400';    desc = 'Tutucu, kaliteli sinyal'; }
  else if (v <= 7)  { label = 'İhtiyatlı';           color = 'text-cyan-400';    desc = 'Düşük frekans'; }
  else if (v <= 9)  { label = 'Ilımlı';              color = 'text-teal-400';    desc = 'Dengeli yaklaşım'; }
  else if (v <= 11) { label = 'Dengeli';             color = 'text-primary';     desc = 'Profesyonel mod'; }
  else if (v <= 13) { label = 'Aktif';               color = 'text-yellow-300';  desc = 'Daha sık işlem'; }
  else if (v <= 15) { label = 'Saldırgan';           color = 'text-yellow-400';  desc = 'Yüksek frekans'; }
  else if (v <= 17) { label = 'Çok Aktif';           color = 'text-orange-400';  desc = 'Scalping ağırlıklı'; }
  else if (v <= 19) { label = 'Yüksek Frekans';     color = 'text-orange-500';  desc = 'Çok sık tarama'; }
  else if (v <= 21) { label = 'Turbo';               color = 'text-red-400';     desc = 'Maksimum frekans'; }
  else if (v <= 23) { label = 'Ultra Saldırı';       color = 'text-red-500';     desc = 'Yüksek risk/ödül'; }
  else              { label = 'Tam Saldırı';         color = 'text-red-600';     desc = 'Limit agresiflik'; }

  // Dinamik parametreler (gösterim için)
  const signalThreshold = Math.round(85 - t * 50);
  const leverageMax     = Math.round(2 + t * 23);
  const maxPositions    = Math.max(1, Math.round(1 + t * 29));
  const cooldown        = Math.max(1, Math.round(45 - t * 44));

  let timeframes;
  if (v <= 5)       timeframes = ['1h', '4h'];
  else if (v <= 9)  timeframes = ['30m', '1h'];
  else if (v <= 13) timeframes = ['15m', '30m'];
  else if (v <= 17) timeframes = ['5m', '15m'];
  else if (v <= 21) timeframes = ['3m', '5m'];
  else              timeframes = ['1m', '3m'];

  return { label, color, desc, signalThreshold, leverageMax, maxPositions, cooldown, timeframes };
}

function getModeLabel(v) {
  if (v <= 7)  return { label: 'SAVUNMACI', color: 'text-blue-400 bg-blue-400/10 border-blue-400/20' };
  if (v <= 14) return { label: 'DENGELİ',   color: 'text-primary bg-primary/10 border-primary/20' };
  if (v <= 20) return { label: 'SALDIRGAN', color: 'text-orange-400 bg-orange-400/10 border-orange-400/20' };
  return              { label: 'TURBO',     color: 'text-red-400 bg-red-400/10 border-red-400/20' };
}

export default function AggressionSlider({ value, onChange, disabled, onSettingsChange, extraSettings }) {
  const meta = getLevelMeta(value);
  const mode = getModeLabel(value);
  const [editing, setEditing] = useState(false);

  // Manuel override alanları (opsiyonel)
  const [tfInput, setTfInput] = useState((extraSettings?.timeframes || meta.timeframes).join(', '));
  const [tempThreshold, setTempThreshold] = useState(extraSettings?.signalThreshold ?? meta.signalThreshold);
  const [tempLeverage, setTempLeverage] = useState(extraSettings?.maxLeverage ?? meta.leverageMax);
  const [tempMaxPos, setTempMaxPos]   = useState(extraSettings?.maxPositions ?? meta.maxPositions);

  const handleSave = () => {
    const parsed = tfInput.split(',').map(t => t.trim()).filter(Boolean);
    onSettingsChange?.({
      timeframes: parsed,
      signalThreshold: tempThreshold,
      maxLeverage: tempLeverage,
      maxPositions: tempMaxPos,
    });
    setEditing(false);
  };

  const handleCancel = () => {
    setTfInput((extraSettings?.timeframes || meta.timeframes).join(', '));
    setTempThreshold(extraSettings?.signalThreshold ?? meta.signalThreshold);
    setTempLeverage(extraSettings?.maxLeverage ?? meta.leverageMax);
    setTempMaxPos(extraSettings?.maxPositions ?? meta.maxPositions);
    setEditing(false);
  };

  // Gösterim: manuel override varsa onu, yoksa otomatik hesaplamayı göster
  const displayTfs       = extraSettings?.timeframes       ?? meta.timeframes;
  const displayThreshold = extraSettings?.signalThreshold  ?? meta.signalThreshold;
  const displayLeverage  = extraSettings?.maxLeverage      ?? meta.leverageMax;
  const displayMaxPos    = extraSettings?.maxPositions     ?? meta.maxPositions;

  // Slider rengi t değerine göre gradient
  const sliderPct = ((value - 1) / 24) * 100;

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-sm font-semibold text-foreground">Davranış Seviyesi</div>
          <div className="text-xs text-muted-foreground">Tüm sistem davranışını kontrol eder</div>
        </div>
        <div className="flex items-center gap-2">
          <div className={cn("px-3 py-1 rounded-full border text-xs font-bold tracking-wide", mode.color)}>
            {mode.label}
          </div>
          <button
            onClick={() => setEditing(!editing)}
            className="p-1.5 rounded-lg bg-secondary hover:bg-border transition-colors"
            title="Manuel Ayarlar"
          >
            <Settings className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Level display */}
      <div className="mb-4">
        <div className="flex items-end justify-between mb-3">
          <div>
            <span className={cn("text-3xl font-bold font-mono", meta.color)}>{value}</span>
            <span className="text-muted-foreground text-sm">/25</span>
          </div>
          <div className="text-right">
            <div className={cn("text-sm font-semibold", meta.color)}>{meta.label}</div>
            <div className="text-xs text-muted-foreground">{meta.desc}</div>
          </div>
        </div>

        <Slider
          value={[value]}
          onValueChange={([v]) => onChange(v)}
          min={1} max={25} step={1}
          disabled={disabled}
          className="w-full"
        />

        <div className="flex justify-between mt-1.5 text-xs text-muted-foreground">
          <span>1 — Güvenli</span>
          <span>13 — Dengeli</span>
          <span>25 — Turbo</span>
        </div>
      </div>

      {/* Manuel Ayar Paneli */}
      {editing && (
        <div className="mb-4 p-3 bg-secondary/50 rounded-lg border border-border space-y-3">
          <div className="text-xs font-semibold text-foreground mb-2">Manuel Ayarlar (opsiyonel override)</div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">
              Zaman Çerçeveleri <span className="text-muted-foreground/60">(virgülle: 1m, 5m, 15m)</span>
            </label>
            <input
              className="w-full bg-card border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary"
              value={tfInput}
              onChange={e => setTfInput(e.target.value)}
              placeholder="ör: 1m, 5m, 15m"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">
              Sinyal Eşiği: <span className="text-foreground font-semibold">{tempThreshold}%+</span>
            </label>
            <Slider value={[tempThreshold]} onValueChange={([v]) => setTempThreshold(v)} min={10} max={95} step={1} className="w-full" />
            <div className="flex justify-between mt-1 text-xs text-muted-foreground"><span>10%</span><span>50%</span><span>95%</span></div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Max Kaldıraç: <span className="text-foreground font-semibold">{tempLeverage}x</span></label>
              <Slider value={[tempLeverage]} onValueChange={([v]) => setTempLeverage(v)} min={1} max={75} step={1} className="w-full" />
              <div className="flex justify-between mt-1 text-xs text-muted-foreground"><span>1x</span><span>37x</span><span>75x</span></div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Max Pozisyon: <span className="text-foreground font-semibold">{tempMaxPos}</span></label>
              <Slider value={[tempMaxPos]} onValueChange={([v]) => setTempMaxPos(v)} min={1} max={100} step={1} className="w-full" />
              <div className="flex justify-between mt-1 text-xs text-muted-foreground"><span>1</span><span>50</span><span>100</span></div>
            </div>
          </div>

          <div className="flex gap-2 pt-1">
            <button onClick={handleSave} className="flex-1 flex items-center justify-center gap-1 bg-primary text-primary-foreground rounded-lg px-3 py-1.5 text-xs font-semibold">
              <Check className="w-3 h-3" /> Kaydet
            </button>
            <button onClick={handleCancel} className="flex items-center gap-1 bg-secondary border border-border rounded-lg px-3 py-1.5 text-xs">
              <X className="w-3 h-3" /> İptal
            </button>
          </div>
        </div>
      )}

      {/* Info grid */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="bg-secondary rounded-lg px-3 py-2">
          <div className="text-muted-foreground mb-0.5">Zaman Çerçeveleri</div>
          <div className="text-foreground font-medium">{displayTfs.join(', ')}</div>
        </div>
        <div className="bg-secondary rounded-lg px-3 py-2 cursor-pointer hover:bg-border/50 transition-colors" onClick={() => setEditing(true)}>
          <div className="text-muted-foreground mb-0.5">Max Kaldıraç</div>
          <div className="text-foreground font-medium">{displayLeverage}x</div>
        </div>
        <div className="bg-secondary rounded-lg px-3 py-2">
          <div className="text-muted-foreground mb-0.5">Sinyal Eşiği</div>
          <div className="text-foreground font-medium">{displayThreshold}%+</div>
        </div>
        <div className="bg-secondary rounded-lg px-3 py-2 cursor-pointer hover:bg-border/50 transition-colors" onClick={() => setEditing(true)}>
          <div className="text-muted-foreground mb-0.5">Max Pozisyonlar</div>
          <div className="text-foreground font-medium">{displayMaxPos}</div>
        </div>
      </div>
    </div>
  );
}