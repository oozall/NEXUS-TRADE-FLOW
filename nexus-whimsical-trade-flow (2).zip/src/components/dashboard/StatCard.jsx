import React from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown } from 'lucide-react';

export default function StatCard({ title, value, subtitle, trend, trendValue, icon: Icon, accent = false, className }) {
  const positive = trendValue > 0;
  return (
    <div className={cn("bg-card border border-border rounded-xl p-4 card-hover", className)}>
      <div className="flex items-start justify-between mb-3">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{title}</div>
        {Icon && (
          <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", accent ? "bg-primary/10" : "bg-secondary")}>
            <Icon className={cn("w-4 h-4", accent ? "text-primary" : "text-muted-foreground")} />
          </div>
        )}
      </div>
      <div className="text-2xl font-bold font-mono mb-1">{value}</div>
      {subtitle && <div className="text-xs text-muted-foreground">{subtitle}</div>}
      {trend !== undefined && (
        <div className={cn("flex items-center gap-1 text-xs mt-2 font-medium", positive ? "text-profit" : "text-loss")}>
          {positive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
          {trendValue > 0 ? '+' : ''}{trendValue?.toFixed(2)}%
        </div>
      )}
    </div>
  );
}