import React from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function SignalRow({ signal }) {
  const isLong = signal.direction === 'LONG';
  const conf = signal.confidence || 0;
  const confColor = conf >= 75 ? 'text-primary' : conf >= 55 ? 'text-yellow-400' : 'text-muted-foreground';

  return (
    <div className="flex items-center gap-3 py-2.5 border-b border-border/50 last:border-0">
      <div className={cn(
        "w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0",
        isLong ? "bg-primary/10" : "bg-red-500/10"
      )}>
        {isLong
          ? <TrendingUp className="w-3.5 h-3.5 text-primary" />
          : <TrendingDown className="w-3.5 h-3.5 text-red-400" />
        }
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-sm">{signal.symbol?.replace('USDT', '')}</span>
          <span className={cn("text-xs px-1.5 py-0.5 rounded font-bold", isLong ? "bg-primary/10 text-primary" : "bg-red-500/10 text-red-400")}>
            {signal.direction === 'LONG' ? 'UZUN' : 'KISA'}
          </span>
          <span className="text-xs text-muted-foreground">{signal.timeframe}</span>
        </div>
        <div className="text-xs text-muted-foreground truncate">{signal.strategy?.replace(/_/g, ' ').replace('trend continuation', 'trend devamı').replace('breakout expansion', 'kırılım genişlemesi').replace('squeeze momentum', 'sıkışma momentumu').replace('momentum burst', 'momentum patlaması').replace('mean reversion', 'ortalamaya dönüş').replace('pullback continuation', 'geri çekilme devamı')}</div>
      </div>
      <div className="text-right">
        <div className={cn("text-sm font-bold font-mono", confColor)}>{conf}%</div>
        <div className="text-xs text-muted-foreground flex items-center gap-0.5 justify-end">
          <Clock className="w-2.5 h-2.5" />
          {signal.signal_time ? formatDistanceToNow(new Date(signal.signal_time), { addSuffix: true }) : 'now'}
        </div>
      </div>
    </div>
  );
}