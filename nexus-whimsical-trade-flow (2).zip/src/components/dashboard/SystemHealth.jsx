import React from 'react';
import { cn } from '@/lib/utils';
import { useEngine } from '@/lib/engineContext';
import { CheckCircle, AlertCircle, XCircle, Activity } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function SystemHealth() {
  const { engineStatus, apiConfig, marketData } = useEngine();

  const checks = [
    { label: 'Motor', ok: engineStatus.running, warn: !engineStatus.running, msg: engineStatus.running ? 'Çalışıyor' : 'Durduruldu' },
    { label: 'API Anahtarı', ok: apiConfig?.status === 'connected', warn: !!apiConfig && apiConfig.status !== 'connected', msg: apiConfig?.status === 'connected' ? 'Bağlı' : 'Ayarlanmadı' },
    { label: 'Pazar Verileri', ok: marketData.length > 0, warn: false, msg: marketData.length > 0 ? `${marketData.length} sembol` : 'Yükleniyor' },
    { label: 'Güvenli Mod', ok: !engineStatus.safeMode, warn: engineStatus.safeMode, msg: engineStatus.safeMode ? 'AKTIF' : 'Normal' },
  ];

  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="flex items-center gap-2 mb-3">
        <Activity className="w-4 h-4 text-primary" />
        <span className="text-sm font-semibold">Sistem Sağlığı</span>
        {engineStatus.lastScan && (
          <span className="text-xs text-muted-foreground ml-auto">
            Son tarama {formatDistanceToNow(new Date(engineStatus.lastScan), { addSuffix: true })}
          </span>
        )}
      </div>
      <div className="space-y-2">
        {checks.map(c => (
          <div key={c.label} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {c.ok
                ? <CheckCircle className="w-3.5 h-3.5 text-primary" />
                : c.warn
                  ? <AlertCircle className="w-3.5 h-3.5 text-warning" />
                  : <XCircle className="w-3.5 h-3.5 text-muted-foreground" />
              }
              <span className="text-xs text-muted-foreground">{c.label}</span>
            </div>
            <span className={cn(
              "text-xs font-medium",
              c.ok ? "text-primary" : c.warn ? "text-warning" : "text-muted-foreground"
            )}>
              {c.msg}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}