import React from 'react';
import { cn } from '@/lib/utils';
import { X, TrendingUp, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PositionCard({ position, onClose }) {
  const isLong = position.side === 'LONG';
  const pnlPos = position.unrealized_pnl >= 0;

  return (
    <div className={cn(
      "bg-card border rounded-xl p-4 card-hover",
      isLong ? "border-primary/20" : "border-red-500/20"
    )}>
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm">{position.symbol.replace('USDT', '')}</span>
            <span className={cn(
              "text-xs px-1.5 py-0.5 rounded font-bold",
              isLong ? "bg-primary/10 text-primary" : "bg-red-500/10 text-red-400"
            )}>
              {position.side === 'LONG' ? 'UZUN' : 'KISA'}
            </span>
            <span className="text-xs text-muted-foreground bg-secondary px-1.5 py-0.5 rounded">
              {position.leverage}x
            </span>
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">{position.strategy}</div>
        </div>
        {onClose && (
          <Button size="icon" variant="ghost" className="w-7 h-7 -mr-1 -mt-1" onClick={() => onClose(position.id)}>
            <X className="w-3.5 h-3.5" />
          </Button>
        )}
      </div>

      <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs mb-3">
        <div>
          <span className="text-muted-foreground">Entry </span>
          <span className="font-mono font-medium">${position.entry_price?.toFixed(4)}</span>
        </div>
        <div>
          <span className="text-muted-foreground">Current </span>
          <span className="font-mono font-medium">${position.current_price?.toFixed(4)}</span>
        </div>
        <div>
          <span className="text-muted-foreground">Stop </span>
          <span className="font-mono text-red-400">${position.stop_loss?.toFixed(4)}</span>
        </div>
        <div>
          <span className="text-muted-foreground">Target </span>
          <span className="font-mono text-primary">${position.take_profit?.toFixed(4)}</span>
        </div>
      </div>

      <div className={cn(
        "flex items-center justify-between px-3 py-2 rounded-lg",
        pnlPos ? "bg-primary/10" : "bg-red-500/10"
      )}>
        <div className="flex items-center gap-1.5">
          {pnlPos ? <TrendingUp className="w-3.5 h-3.5 text-primary" /> : <TrendingDown className="w-3.5 h-3.5 text-red-400" />}
          <span className="text-xs text-muted-foreground">PnL</span>
        </div>
        <div className="text-right">
          <div className={cn("text-sm font-bold font-mono", pnlPos ? "text-profit" : "text-loss")}>
            {pnlPos ? '+' : ''}{position.unrealized_pnl?.toFixed(2)} USDT
          </div>
          <div className={cn("text-xs font-mono", pnlPos ? "text-profit" : "text-loss")}>
            ({pnlPos ? '+' : ''}{position.unrealized_pnl_pct?.toFixed(2)}%)
          </div>
        </div>
      </div>
    </div>
  );
}