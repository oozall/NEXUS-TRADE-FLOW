import React, { useState } from 'react';
import { Slider } from '@/components/ui/slider';
import { Wallet, Check, X } from 'lucide-react';

export default function PaperBalanceControl({ balance, onBalanceChange, disabled }) {
  const [editing, setEditing] = useState(false);
  const [tempVal, setTempVal] = useState(balance);

  const handleSave = () => {
    onBalanceChange(tempVal);
    setEditing(false);
  };

  const handleCancel = () => {
    setTempVal(balance);
    setEditing(false);
  };

  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Wallet className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold">Paper Bakiye</span>
        </div>
        {!disabled && (
          <button
            onClick={() => setEditing(!editing)}
            className="text-xs text-primary hover:underline"
          >
            {editing ? 'Kapat' : 'Düzenle'}
          </button>
        )}
      </div>

      <div className="text-2xl font-bold font-mono text-primary mb-1">
        ${balance.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
      </div>
      <div className="text-xs text-muted-foreground">Simülasyon bakiyesi</div>

      {editing && (
        <div className="mt-4 space-y-3 pt-3 border-t border-border">
          <div className="text-xs text-muted-foreground mb-1">
            Bakiye: <span className="text-foreground font-bold">${tempVal.toLocaleString()}</span>
          </div>
          <Slider
            value={[tempVal]}
            onValueChange={([v]) => setTempVal(v)}
            min={1}
            max={10000}
            step={1}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>$1</span>
            <span>$5,000</span>
            <span>$10,000</span>
          </div>
          <div className="flex gap-2 mt-2">
            {[100, 500, 1000, 5000, 10000].map(v => (
              <button
                key={v}
                onClick={() => setTempVal(v)}
                className={`flex-1 text-xs py-1 rounded-lg border transition-colors ${tempVal === v ? 'bg-primary text-primary-foreground border-primary' : 'bg-secondary border-border hover:bg-border'}`}
              >
                ${v >= 1000 ? `${v / 1000}K` : v}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleSave}
              className="flex-1 flex items-center justify-center gap-1 bg-primary text-primary-foreground rounded-lg px-3 py-1.5 text-xs font-semibold"
            >
              <Check className="w-3 h-3" /> Kaydet
            </button>
            <button
              onClick={handleCancel}
              className="flex items-center gap-1 bg-secondary border border-border rounded-lg px-3 py-1.5 text-xs"
            >
              <X className="w-3 h-3" /> İptal
            </button>
          </div>
        </div>
      )}
    </div>
  );
}