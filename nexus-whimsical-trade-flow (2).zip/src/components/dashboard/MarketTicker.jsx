import React from 'react';
import { cn } from '@/lib/utils';
import { useEngine } from '@/lib/engineContext';

export default function MarketTicker() {
  const { marketData } = useEngine();
  const items = [...marketData, ...marketData]; // duplicate for seamless scroll

  if (marketData.length === 0) return null;

  return (
    <div className="ticker-wrap bg-secondary border-b border-border py-2">
      <div className="ticker-content gap-8 flex">
        {items.map((item, i) => (
          <div key={i} className="flex items-center gap-2 flex-shrink-0 px-2">
            <span className="text-xs font-bold">{item.symbol.replace('USDT', '')}</span>
            <span className="text-xs font-mono">${item.price < 1 ? item.price.toFixed(5) : item.price < 100 ? item.price.toFixed(3) : item.price.toFixed(1)}</span>
            <span className={cn(
              "text-xs font-mono font-medium",
              item.priceChange >= 0 ? "text-profit" : "text-loss"
            )}>
              {item.priceChange >= 0 ? '+' : ''}{item.priceChange?.toFixed(2)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}