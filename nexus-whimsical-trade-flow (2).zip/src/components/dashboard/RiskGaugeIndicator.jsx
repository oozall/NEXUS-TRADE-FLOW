import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

export default function RiskGaugeIndicator({ totalLeverage, liquidationRisk, openPositions }) {
  const [displayLeverage, setDisplayLeverage] = useState(totalLeverage || 0);

  useEffect(() => {
    // Smooth animation
    const duration = 300; // ms
    const start = displayLeverage;
    const target = totalLeverage || 0;
    const diff = target - start;
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      setDisplayLeverage(start + diff * progress);
      if (progress < 1) requestAnimationFrame(animate);
    };

    animate();
  }, [totalLeverage]);

  // Risk seviyesi (0-100)
  const maxLeverage = 20; // Max 20x
  const riskPercent = Math.min((displayLeverage / maxLeverage) * 100, 100);

  // Renk belirleme (yeşil → sarı → kırmızı)
  const getColor = () => {
    if (riskPercent < 33) return '#10b981'; // Yeşil
    if (riskPercent < 66) return '#f59e0b'; // Sarı
    return '#ef4444'; // Kırmızı
  };

  const getBackgroundColor = () => {
    if (riskPercent < 33) return 'rgba(16, 185, 129, 0.1)';
    if (riskPercent < 66) return 'rgba(245, 158, 11, 0.1)';
    return 'rgba(239, 68, 68, 0.1)';
  };

  const currentColor = getColor();
  const bgColor = getBackgroundColor();

  // SVG Gauge oluştur
  const radius = 45;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - riskPercent / 100);

  return (
    <div className="flex flex-col items-center gap-3 p-4 rounded-xl border border-border bg-card">
      {/* 3D SVG Gauge */}
      <div className="relative w-32 h-32">
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
          {/* Arka halka (gri) */}
          <circle
            cx="60"
            cy="60"
            r={radius}
            fill="none"
            stroke="hsl(var(--muted))"
            strokeWidth="8"
            opacity="0.2"
          />
          
          {/* Risk halkaası (renkli) */}
          <circle
            cx="60"
            cy="60"
            r={radius}
            fill="none"
            stroke={currentColor}
            strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            style={{
              transition: 'stroke-dashoffset 0.3s ease, stroke 0.3s ease',
              filter: `drop-shadow(0 0 8px ${currentColor}80)`,
            }}
          />

          {/* Merkez daire (glow efekti) */}
          <circle
            cx="60"
            cy="60"
            r="20"
            fill={currentColor}
            opacity="0.2"
            style={{
              animation: `pulse 2s ease-in-out infinite`,
            }}
          />

          {/* İç halka */}
          <circle
            cx="60"
            cy="60"
            r="18"
            fill="hsl(var(--card))"
            stroke={currentColor}
            strokeWidth="1"
            opacity="0.8"
          />

          {/* İbre (akrep) */}
          <g>
            <line
              x1="60"
              y1="60"
              x2={60 + radius * Math.cos((riskPercent / 100 - 0.25) * Math.PI * 2)}
              y2={60 + radius * Math.sin((riskPercent / 100 - 0.25) * Math.PI * 2)}
              stroke={currentColor}
              strokeWidth="3"
              strokeLinecap="round"
              style={{
                transition: 'all 0.3s ease',
                filter: `drop-shadow(0 0 4px ${currentColor})`,
              }}
            />
            {/* İbre başı */}
            <circle
              cx="60"
              cy="60"
              r="3"
              fill={currentColor}
            />
          </g>
        </svg>

        {/* Merkez Bilgi */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-xl font-bold text-foreground">
            {displayLeverage.toFixed(1)}x
          </div>
          <div className="text-xs text-muted-foreground">Toplam Lev.</div>
        </div>
      </div>

      {/* İstatistikler */}
      <div className="w-full grid grid-cols-3 gap-2 text-center text-xs">
        <div className="p-2 rounded bg-muted/30">
          <div className="text-muted-foreground">İşlem</div>
          <div className="font-bold text-foreground">{openPositions}</div>
        </div>
        <div className="p-2 rounded bg-muted/30">
          <div className="text-muted-foreground">Risk</div>
          <div className={cn(
            "font-bold",
            riskPercent < 33 ? "text-green-500" : riskPercent < 66 ? "text-yellow-500" : "text-red-500"
          )}>
            {riskPercent.toFixed(0)}%
          </div>
        </div>
        <div className="p-2 rounded bg-muted/30">
          <div className="text-muted-foreground">Likit</div>
          <div className={cn(
            "font-bold",
            liquidationRisk < 5 ? "text-green-500" : liquidationRisk < 15 ? "text-yellow-500" : "text-red-500"
          )}>
            {liquidationRisk.toFixed(1)}%
          </div>
        </div>
      </div>

      {/* Uyarı */}
      {riskPercent >= 66 && (
        <div className="w-full p-2 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-400 text-center">
          ⚠️ Yüksek Risk - Pozisyon Kapatmayı Düşün
        </div>
      )}
      {riskPercent >= 33 && riskPercent < 66 && (
        <div className="w-full p-2 rounded-lg bg-yellow-500/10 border border-yellow-500/30 text-xs text-yellow-400 text-center">
          ⚠️ Orta Risk - Dikkat Edin
        </div>
      )}

      <style>{`
        @keyframes pulse {
          0%, 100% { r: 20; opacity: 0.2; }
          50% { r: 22; opacity: 0.4; }
        }
      `}</style>
    </div>
  );
}