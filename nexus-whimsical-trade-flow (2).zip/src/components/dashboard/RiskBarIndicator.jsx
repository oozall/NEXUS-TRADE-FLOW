import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

export default function RiskBarIndicator({ totalLeverage, liquidationRisk, openPositions }) {
  const [displayRisk, setDisplayRisk] = useState(liquidationRisk || 0);

  useEffect(() => {
    const duration = 500;
    const start = displayRisk;
    const target = liquidationRisk || 0;
    const diff = target - start;
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      setDisplayRisk(start + diff * progress);
      if (progress < 1) requestAnimationFrame(animate);
    };

    animate();
  }, [liquidationRisk]);

  // 0-100% risk
  const riskPercent = Math.min(Math.max(displayRisk, 0), 100);

  // Renk (yeşil → sarı → kırmızı)
  const getColor = () => {
    if (riskPercent < 33) return '#10b981';
    if (riskPercent < 66) return '#f59e0b';
    return '#ef4444';
  };

  const currentColor = getColor();

  return (
    <div className="w-full p-3 rounded-lg border border-border bg-card/50">
      {/* Başlık */}
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold text-muted-foreground">RISK GÖSTERGESI</span>
        <span className={cn(
          "text-sm font-bold",
          riskPercent < 33 ? "text-green-500" : riskPercent < 66 ? "text-yellow-500" : "text-red-500"
        )}>
          {riskPercent.toFixed(0)}%
        </span>
      </div>

      {/* Progress Bar */}
      <div className="relative h-6 rounded-full bg-muted/20 border border-border overflow-hidden">
        {/* Dolu kısım */}
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${riskPercent}%`,
            backgroundColor: currentColor,
            boxShadow: `0 0 12px ${currentColor}80`,
          }}
        />

        {/* İbre (merkez çizgi) */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-foreground/30 transition-all duration-500"
          style={{
            left: `${riskPercent}%`,
            transform: 'translateX(-50%)',
          }}
        />

        {/* Rakamlar (0, 50, 100) */}
        <div className="absolute inset-0 flex items-center justify-between px-2 pointer-events-none">
          <span className="text-[10px] text-muted-foreground font-mono">0</span>
          <span className="text-[10px] text-muted-foreground font-mono">50</span>
          <span className="text-[10px] text-muted-foreground font-mono">100</span>
        </div>
      </div>

      {/* Bilgi */}
      <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
        <span>{openPositions} işlem</span>
        <span>{totalLeverage.toFixed(1)}x avg</span>
      </div>
    </div>
  );
}