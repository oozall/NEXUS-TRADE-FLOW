import React from 'react';
import { cn } from '@/lib/utils';
import { Card } from '@/components/ui/card';

const MODE_METADATA = {
  TREND_FOLLOWING: { name: 'Trend Takip', icon: '📈', color: 'bg-primary' },
  RANGE_MEAN_REVERSION: { name: 'Range', icon: '↔️', color: 'bg-blue-500' },
  BREAKOUT: { name: 'Kırılım', icon: '🔨', color: 'bg-yellow-500' },
  MOMENTUM: { name: 'Momentum', icon: '⚡', color: 'bg-orange-500' },
  SCALPING: { name: 'Scalping', icon: '📍', color: 'bg-green-500' },
  RISK_OFF: { name: 'Risk-Off', icon: '⏸️', color: 'bg-red-500' },
  PROTECTIVE: { name: 'Koruyucu', icon: '🛡️', color: 'bg-purple-500' }
};

export default function ModeScoreCard({ mode, score, isActive }) {
  const metadata = MODE_METADATA[mode];
  
  let status = 'PASSIVE';
  if (score >= 75) status = 'ACTIVE';
  else if (score >= 60) status = 'CANDIDATE';

  const getStatusColor = () => {
    if (status === 'ACTIVE') return 'text-green-400 bg-green-500/10 border-green-500/30';
    if (status === 'CANDIDATE') return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/30';
    return 'text-muted-foreground bg-muted/10 border-border';
  };

  const getScoreBarColor = () => {
    if (score >= 75) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-muted-foreground';
  };

  return (
    <Card className={cn(
      "p-3 border transition-all",
      isActive && "ring-2 ring-primary border-primary/50 bg-primary/5"
    )}>
      <div className="flex items-center gap-2 mb-2">
        <span className="text-xl">{metadata.icon}</span>
        <div className="flex-1">
          <h4 className="text-xs font-bold">{metadata.name}</h4>
        </div>
        <div className="text-right">
          <div className="text-lg font-bold text-foreground">{score}</div>
          <div className="text-xs text-muted-foreground">/100</div>
        </div>
      </div>

      {/* Score Bar */}
      <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden mb-2">
        <div
          className={cn("h-full transition-all duration-300", getScoreBarColor())}
          style={{ width: `${Math.min(score, 100)}%` }}
        />
      </div>

      {/* Status Badge */}
      <div className={cn(
        "px-2 py-1 rounded text-xs font-semibold border",
        getStatusColor()
      )}>
        {status === 'ACTIVE' && '✓ AKTİF'}
        {status === 'CANDIDATE' && '◐ ADAY'}
        {status === 'PASSIVE' && '○ PASİF'}
      </div>

      {/* Active Indicator */}
      {isActive && (
        <div className="mt-2 p-1.5 rounded-lg bg-primary/20 border border-primary/40">
          <div className="text-xs text-primary font-semibold">🟢 Bu mod seçildi</div>
        </div>
      )}
    </Card>
  );
}