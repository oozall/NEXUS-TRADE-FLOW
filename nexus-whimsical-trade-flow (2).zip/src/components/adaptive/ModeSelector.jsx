import React from 'react';
import { useAdaptiveEngine } from '@/lib/adaptiveEngineContext';
import { cn } from '@/lib/utils';
import { Card } from '@/components/ui/card';
import { ChevronRight } from 'lucide-react';

export default function ModeSelector() {
  const { currentMode, MODE_METADATA, modeChangeReason, marketRegime } = useAdaptiveEngine();
  const metadata = MODE_METADATA[currentMode];

  return (
    <Card className="p-4 bg-gradient-to-r from-card to-secondary border-primary/20">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl">{metadata.icon}</span>
            <div>
              <h3 className="font-bold text-foreground">{metadata.name}</h3>
              <p className="text-xs text-muted-foreground">{metadata.description}</p>
            </div>
          </div>
          
          <div className="mt-3 p-2.5 rounded-lg bg-background/50 border border-border">
            <div className="text-xs">
              <span className="text-muted-foreground">Seçilme Sebebi: </span>
              <span className="text-foreground font-medium">{modeChangeReason}</span>
            </div>
          </div>

          {marketRegime && (
            <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded bg-background/50 border border-border/50">
                <div className="text-muted-foreground">Trend Gücü</div>
                <div className="font-bold text-primary">{marketRegime.trend_strength}%</div>
              </div>
              <div className="p-2 rounded bg-background/50 border border-border/50">
                <div className="text-muted-foreground">Volatilite</div>
                <div className="font-bold">{marketRegime.volatility_level}</div>
              </div>
              <div className="p-2 rounded bg-background/50 border border-border/50">
                <div className="text-muted-foreground">Hacim</div>
                <div className="font-bold">{marketRegime.volume_strength}</div>
              </div>
              <div className="p-2 rounded bg-background/50 border border-border/50">
                <div className="text-muted-foreground">Likidite</div>
                <div className="font-bold">{marketRegime.liquidity_quality}</div>
              </div>
            </div>
          )}
        </div>

        <div className={cn(
          "w-16 h-16 rounded-lg flex items-center justify-center text-3xl flex-shrink-0",
          metadata.bg
        )}>
          {metadata.icon}
        </div>
      </div>
    </Card>
  );
}