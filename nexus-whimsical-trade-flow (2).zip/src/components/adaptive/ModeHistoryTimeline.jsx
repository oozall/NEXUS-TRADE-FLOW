import React from 'react';
import { cn } from '@/lib/utils';
import { Card } from '@/components/ui/card';
import { ChevronRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const MODE_METADATA = {
  TREND_FOLLOWING: { name: 'Trend Takip', icon: '📈' },
  RANGE_MEAN_REVERSION: { name: 'Range', icon: '↔️' },
  BREAKOUT: { name: 'Kırılım', icon: '🔨' },
  MOMENTUM: { name: 'Momentum', icon: '⚡' },
  SCALPING: { name: 'Scalping', icon: '📍' },
  RISK_OFF: { name: 'Risk-Off', icon: '⏸️' },
  PROTECTIVE: { name: 'Koruyucu', icon: '🛡️' }
};

export default function ModeHistoryTimeline({ modeHistory = [] }) {

  if (modeHistory.length === 0) {
    return (
      <Card className="p-4 text-center text-sm text-muted-foreground">
        Henüz mod değişikliği yok
      </Card>
    );
  }

  return (
    <Card className="p-4">
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {[...modeHistory].reverse().map((change, idx) => {
          const fromMeta = MODE_METADATA[change.from];
          const toMeta = MODE_METADATA[change.to];

          return (
            <div key={idx} className="p-2.5 rounded-lg bg-secondary/50 border border-border/50">
              <div className="flex items-center gap-2 mb-1 text-xs">
                <span className="text-lg">{fromMeta?.icon || '?'}</span>
                <ChevronRight className="w-3 h-3 text-muted-foreground" />
                <span className="text-lg">{toMeta?.icon || '?'}</span>
                <span className="text-muted-foreground ml-auto text-xs">
                  {formatDistanceToNow(new Date(change.timestamp), { addSuffix: true })}
                </span>
              </div>
              <div className="text-muted-foreground text-xs mb-1.5">{change.reason}</div>
              {change.scores && (
                <div className="text-xs border-t border-border/50 pt-1.5 grid grid-cols-2 gap-1">
                  <div className="text-muted-foreground">
                    <span className="font-semibold text-foreground">{change.scores[change.to]?.toFixed(0)}</span>/100
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </Card>
  );
}