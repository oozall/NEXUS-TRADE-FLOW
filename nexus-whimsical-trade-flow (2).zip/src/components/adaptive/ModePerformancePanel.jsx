import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import { Card } from '@/components/ui/card';
import { TrendingUp, TrendingDown } from 'lucide-react';

const MODES = {
  TREND_FOLLOWING: 'TREND_FOLLOWING',
  RANGE_MEAN_REVERSION: 'RANGE_MEAN_REVERSION',
  BREAKOUT: 'BREAKOUT',
  MOMENTUM: 'MOMENTUM',
  SCALPING: 'SCALPING',
  RISK_OFF: 'RISK_OFF',
  PROTECTIVE: 'PROTECTIVE'
};

const MODE_METADATA = {
  TREND_FOLLOWING: { name: 'Trend Takip', icon: '📈' },
  RANGE_MEAN_REVERSION: { name: 'Range', icon: '↔️' },
  BREAKOUT: { name: 'Kırılım', icon: '🔨' },
  MOMENTUM: { name: 'Momentum', icon: '⚡' },
  SCALPING: { name: 'Scalping', icon: '📍' },
  RISK_OFF: { name: 'Risk-Off', icon: '⏸️' },
  PROTECTIVE: { name: 'Koruyucu', icon: '🛡️' }
};

export default function ModePerformancePanel() {
  const [performances, setPerformances] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadModePerformances();
  }, []);

  const loadModePerformances = async () => {
    try {
      const records = await base44.entities.ModePerformance.list();
      const map = {};
      records.forEach(r => {
        map[r.mode] = r;
      });
      setPerformances(map);
    } catch (error) {
      console.log('Mode performans yükleme:', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
      {Object.entries(MODES).map(([modeKey, mode]) => {
        const meta = MODE_METADATA[mode];
        const perf = performances[mode];
        const isPositive = (perf?.total_pnl || 0) > 0;

        return (
          <Card key={mode} className={cn(
            "p-3 border transition-all",
            perf?.total_pnl > 0 ? "border-primary/30 bg-primary/5" : "border-border"
          )}>
            <div className="flex items-start justify-between gap-2 mb-2">
              <div>
                <div className="text-lg">{meta.icon}</div>
                <h4 className="text-xs font-bold mt-1 line-clamp-2">{meta.name}</h4>
              </div>
            </div>

            {perf ? (
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Win Rate</span>
                  <span className={cn("font-bold", perf.win_rate >= 50 ? "text-profit" : "text-loss")}>
                    {perf.win_rate?.toFixed(0)}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">İşlem</span>
                  <span className="font-bold">{perf.total_trades}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">PnL</span>
                  <span className={cn("font-bold font-mono", isPositive ? "text-profit" : "text-loss")}>
                    {isPositive ? '+' : ''}{perf.total_pnl?.toFixed(2)}
                  </span>
                </div>
                <div className="pt-1.5 border-t border-border text-muted-foreground text-xs">
                  Son {perf.period}
                </div>
              </div>
            ) : (
              <div className="text-xs text-muted-foreground italic">Veri yok</div>
            )}
          </Card>
        );
      })}
    </div>
  );
}