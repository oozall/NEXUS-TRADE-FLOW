import React from 'react';
import { cn } from '@/lib/utils';
import { Card } from '@/components/ui/card';

const MODES = {
  TREND_FOLLOWING: { name: 'Trend Takip', icon: '📈', color: 'bg-primary' },
  RANGE_MEAN_REVERSION: { name: 'Range', icon: '↔️', color: 'bg-blue-500' },
  BREAKOUT: { name: 'Kırılım', icon: '🔨', color: 'bg-yellow-500' },
  MOMENTUM: { name: 'Momentum', icon: '⚡', color: 'bg-orange-500' },
  SCALPING: { name: 'Scalping', icon: '📍', color: 'bg-green-500' },
  RISK_OFF: { name: 'Risk-Off', icon: '⏸️', color: 'bg-red-500' },
  PROTECTIVE: { name: 'Koruyucu', icon: '🛡️', color: 'bg-purple-500' }
};

export default function ScoreSummaryGrid({ finalScores, normalizedScores, activeMode, probabilities }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
      {Object.entries(MODES).map(([modeKey, metadata]) => {
        const finalScore = finalScores[modeKey] || 0;
        const normalized = normalizedScores[modeKey] || 0;
        const probability = probabilities?.[modeKey] || 0;
        const isActive = activeMode === modeKey;

        const getStatus = (score) => {
          if (score >= 75) return { text: 'AKTİF', color: 'bg-green-500/20 text-green-400 border-green-500/30' };
          if (score >= 60) return { text: 'ADAY', color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' };
          return { text: 'PASİF', color: 'bg-muted/20 text-muted-foreground border-muted/30' };
        };

        const status = getStatus(finalScore);

        return (
          <Card key={modeKey} className={cn(
            "p-2.5 border transition-all",
            isActive && "ring-2 ring-primary border-primary/50 bg-primary/5",
            "hover:border-primary/20"
          )}>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <span className="text-lg">{metadata.icon}</span>
                <div>
                  <h4 className="text-xs font-bold leading-tight">{metadata.name}</h4>
                </div>
              </div>
              {isActive && <span className="text-xs font-bold text-primary">⭐</span>}
            </div>

            {/* Skorlar */}
            <div className="space-y-1 mb-2 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ham</span>
                <span className="font-mono text-xs">{normalized.toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Nihai</span>
                <span className="font-mono font-bold text-sm text-foreground">{finalScore.toFixed(1)}</span>
              </div>
              {probability > 0 && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Olasılık</span>
                  <span className="font-mono text-xs">{(probability * 100).toFixed(0)}%</span>
                </div>
              )}
            </div>

            {/* Progress Bar */}
            <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden mb-2">
              <div
                className={cn("h-full transition-all", metadata.color)}
                style={{ width: `${Math.min(finalScore, 100)}%` }}
              />
            </div>

            {/* Status Badge */}
            <div className={cn(
              "px-1.5 py-0.5 rounded text-xs font-semibold border",
              status.color
            )}>
              {status.text}
            </div>
          </Card>
        );
      })}
    </div>
  );
}