import React from 'react';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

export default function ScoreCalculationDetail({ mode, details }) {
  if (!details) return null;

  const getStatusColor = (score) => {
    if (score >= 75) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-muted-foreground';
  };

  const statusText = (score) => {
    if (score >= 75) return 'AKTİF';
    if (score >= 60) return 'ADAY';
    return 'PASİF';
  };

  return (
    <Card className="p-4 border-border/50 bg-secondary/30">
      <h4 className="font-semibold text-sm mb-4">{mode} - Skor Hesaplaması</h4>

      <div className="space-y-3">
        {/* 1. Ham Skor */}
        <div className="p-2.5 rounded-lg bg-card border border-border">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-muted-foreground">1. Ham Skor</span>
            <span className="font-mono text-sm font-bold">{details.rawScore.toFixed(1)} / {details.maxScore}</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500"
              style={{ width: `${Math.min((details.rawScore / details.maxScore) * 100, 100)}%` }}
            />
          </div>
        </div>

        {/* 2. Normalize Skor */}
        <div className="p-2.5 rounded-lg bg-card border border-border">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-muted-foreground">2. Normalize Skor</span>
            <span className="font-mono text-sm font-bold">{details.normalizedScore} / 100</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary"
              style={{ width: `${Math.min(parseFloat(details.normalizedScore), 100)}%` }}
            />
          </div>
        </div>

        {/* Çarpanlar */}
        <div className="grid grid-cols-2 gap-2 p-2.5 rounded-lg bg-card border border-border">
          <div>
            <div className="text-xs text-muted-foreground mb-1">Timeframe</div>
            <div className="font-mono font-bold text-sm">×{details.multipliers.timeframe}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground mb-1">Agresiflik</div>
            <div className="font-mono font-bold text-sm">×{details.multipliers.aggression}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground mb-1">Performans</div>
            <div className="font-mono font-bold text-sm">×{details.multipliers.performance}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground mb-1">Volatilite</div>
            <div className="font-mono font-bold text-sm">×{details.multipliers.volatility}</div>
          </div>
        </div>

        {/* Nihai Skor */}
        <div className="p-3 rounded-lg bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/30">
          <div className="flex justify-between items-center">
            <span className="text-sm font-semibold">Nihai Skor</span>
            <div className="flex items-center gap-2">
              <span className={cn("font-mono text-2xl font-bold", getStatusColor(parseFloat(details.finalScore)))}>
                {details.finalScore}
              </span>
              <span className={cn("text-xs font-bold px-2 py-1 rounded", 
                parseFloat(details.finalScore) >= 75 ? "bg-green-500/20 text-green-400" :
                parseFloat(details.finalScore) >= 60 ? "bg-yellow-500/20 text-yellow-400" :
                "bg-muted text-muted-foreground"
              )}>
                {statusText(parseFloat(details.finalScore))}
              </span>
            </div>
          </div>
        </div>

        {/* İşlem */}
        <div className="text-xs text-muted-foreground p-2 rounded bg-muted/30 font-mono">
          <div>normalize({details.rawScore.toFixed(1)}, {details.maxScore})</div>
          <div>× {details.multipliers.timeframe} (tf) × {details.multipliers.aggression} (agg) × {details.multipliers.performance} (perf) × {details.multipliers.volatility} (vol)</div>
          <div>= {details.finalScore}</div>
        </div>
      </div>
    </Card>
  );
}