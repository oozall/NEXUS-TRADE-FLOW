import React from 'react';
import { Card } from '@/components/ui/card';

const SCORE_CRITERIA = {
  TREND_FOLLOWING: [
    { label: 'Trend Gücü (ADX)', max: 30 },
    { label: 'Yapısal Trend', max: 20 },
    { label: 'EMA Uyumu', max: 15 },
    { label: 'Hacim Uyumu', max: 15 },
    { label: 'Volatilite', max: 10 }
  ],
  RANGE_MEAN_REVERSION: [
    { label: 'ADX Düşük', max: 25 },
    { label: 'Fiyat Bandında', max: 20 },
    { label: 'Sıkışma', max: 15 },
    { label: 'Hacim Zayıf', max: 10 },
    { label: 'Trend Modu Kötü', max: 10 }
  ],
  BREAKOUT: [
    { label: 'Sıkışma Süresi', max: 20 },
    { label: 'ATR Daralması', max: 20 },
    { label: 'Hacim Artışı', max: 25 },
    { label: 'Güçlü Kapanış', max: 20 },
    { label: 'Fake Geçmiş', max: -10 }
  ],
  MOMENTUM: [
    { label: 'Mum Gövde', max: 15 },
    { label: 'Güçlü Mumlar', max: 20 },
    { label: 'Hacim Momentum', max: 20 },
    { label: 'Trend Oturmamış', max: 10 }
  ],
  SCALPING: [
    { label: 'Spread', max: 20 },
    { label: 'Likidite', max: 20 },
    { label: 'Mikro Yapı', max: 20 },
    { label: 'Komisyon Edge', max: 10 }
  ],
  RISK_OFF: [
    { label: 'Spread Anomali', max: 40 },
    { label: 'Volatilite', max: 30 },
    { label: 'Veri Sorunu', max: 30 },
    { label: 'Ardışık Kayıp', max: 25 }
  ],
  PROTECTIVE: [
    { label: 'Günlük Zarar', max: 30 },
    { label: 'Performans Düşüş', max: 20 },
    { label: 'Güven Düşük', max: 15 },
    { label: 'Kararsızlık', max: 15 }
  ]
};

export default function ScoreBreakdown({ mode, score }) {
  const criteria = SCORE_CRITERIA[mode] || [];

  return (
    <Card className="p-4 border-border/50">
      <h4 className="font-semibold text-sm mb-3">{mode} - Skor Detayları</h4>
      <div className="space-y-2">
        {criteria.map((c, idx) => (
          <div key={idx} className="flex items-center gap-2 text-xs">
            <span className="text-muted-foreground flex-1">{c.label}</span>
            <div className="text-right">
              <span className="font-semibold">{c.max > 0 ? '+' : ''}{c.max}</span>
              <span className="text-muted-foreground"> / {Math.abs(c.max)}</span>
            </div>
          </div>
        ))}
        <div className="pt-2 border-t border-border/50 flex justify-between text-xs font-bold">
          <span>Toplam</span>
          <span className="text-primary">{score} / 100</span>
        </div>
      </div>
    </Card>
  );
}