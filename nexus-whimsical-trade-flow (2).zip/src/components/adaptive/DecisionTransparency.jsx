import React from 'react';
import { Card } from '@/components/ui/card';
import { AlertCircle, CheckCircle, Lock } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function DecisionTransparency({ decision }) {
  if (!decision) return null;

  const canTrade = decision.canOpenTrade;

  return (
    <Card className={cn(
      "p-4 border-2 transition-all",
      canTrade
        ? "border-green-500/30 bg-green-500/5"
        : "border-red-500/30 bg-red-500/5"
    )}>
      <div className="flex items-start gap-3 mb-4">
        {canTrade ? (
          <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
        ) : (
          <Lock className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
        )}
        <div className="flex-1">
          <h3 className={cn(
            "font-bold text-sm",
            canTrade ? "text-green-400" : "text-red-400"
          )}>
            {canTrade ? '✓ İŞLEM AÇILABILIR' : '✗ İŞLEM AÇILMAYACAK'}
          </h3>
          <p className="text-xs text-muted-foreground mt-1">{decision.entryReason}</p>
        </div>
      </div>

      {/* Sembol Doğrulama */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
        <div className="p-2.5 rounded-lg bg-card border border-border">
          <div className="text-xs text-muted-foreground mb-1">Sembol Doğrulama</div>
          <div className={cn(
            "text-xs font-bold",
            decision.symbolValid ? "text-green-400" : "text-red-400"
          )}>
            {decision.symbolValid ? '✓ Geçerli' : '✗ Geçersiz'}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">{decision.symbolReason}</div>
        </div>

        <div className="p-2.5 rounded-lg bg-card border border-border">
          <div className="text-xs text-muted-foreground mb-1">Giriş Kuralları</div>
          <div className={cn(
            "text-xs font-bold",
            decision.entryRulesPass ? "text-green-400" : "text-red-400"
          )}>
            {decision.entryRulesPass ? '✓ Sağlandı' : '✗ Başarısız'}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            {decision.entryRulesPass ? 'Tüm şartlar tamam' : 'Bazı şartlar eksik'}
          </div>
        </div>
      </div>

      {/* Risk Parametreleri */}
      {decision.riskParameters && (
        <div className="bg-secondary/30 rounded-lg p-3 mb-3">
          <div className="text-xs font-semibold mb-2 text-muted-foreground">RİSK PARAMETRELERİ</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="text-xs">
              <div className="text-muted-foreground">Kaldıraç</div>
              <div className="font-mono font-bold">{decision.riskParameters.leverage}x</div>
            </div>
            <div className="text-xs">
              <div className="text-muted-foreground">Stop Mesafe</div>
              <div className="font-mono font-bold">{decision.riskParameters.stopDistance.toFixed(2)}%</div>
            </div>
            <div className="text-xs">
              <div className="text-muted-foreground">TP Ratio</div>
              <div className="font-mono font-bold">{decision.riskParameters.takeProfitRatio.toFixed(2)}</div>
            </div>
            <div className="text-xs">
              <div className="text-muted-foreground">Max Pozisyon</div>
              <div className="font-mono font-bold">{decision.riskParameters.maxPositions}</div>
            </div>
          </div>
        </div>
      )}

      {/* Piyasa Snapshot */}
      {decision.marketSnapshot && (
        <div className="text-xs text-muted-foreground space-y-1 p-2.5 rounded-lg bg-muted/20">
          <div className="font-semibold mb-1.5">PIYASA SNAPSHOT</div>
          <div className="flex justify-between">
            <span>Trend Gücü</span>
            <span className="font-mono">{decision.marketSnapshot.trendStrength?.toFixed(1) || 'N/A'}</span>
          </div>
          <div className="flex justify-between">
            <span>Volatilite</span>
            <span className="font-mono">{decision.marketSnapshot.volatility || 'N/A'}</span>
          </div>
          <div className="flex justify-between">
            <span>Sıkışma</span>
            <span className="font-mono">{decision.marketSnapshot.squeeze ? 'Evet' : 'Hayır'}</span>
          </div>
        </div>
      )}
    </Card>
  );
}