import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import { X, Play, Loader2, TrendingUp, TrendingDown, BarChart2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const POPULAR_PAIRS = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT', 'AVAXUSDT'];
const PERIODS = [
  { label: '30 Gün', value: 30 },
  { label: '60 Gün', value: 60 },
  { label: '90 Gün', value: 90 },
  { label: '180 Gün', value: 180 },
];

export default function BacktestPanel({ strategy, onClose }) {
  const [symbols, setSymbols] = useState(['BTCUSDT']);
  const [period, setPeriod] = useState(90);
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState(null);

  const toggleSymbol = (s) => {
    setSymbols(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  };

  const runBacktest = async () => {
    if (symbols.length === 0) { toast.error('En az 1 parite seç'); return; }
    setRunning(true);
    setResults(null);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Sen bir kripto trading backtest uzmanısın. Aşağıdaki stratejiyi verilen paritelerde ${period} günlük geçmiş verilerle simüle et.

Strateji: "${strategy.name}"
Açıklama: ${strategy.description}
Giriş Sinyali: ${strategy.entry_signal}
Çıkış Sinyali: ${strategy.exit_signal}
Kurallar: ${(strategy.rules || []).join(' | ')}
Beklenen Kazanç Oranı: ${strategy.expected_winrate}%
Risk/Reward: ${strategy.risk_reward}
Timeframe: ${strategy.timeframe || '15m'}
Kaldıraç: ${strategy.leverage || 5}x
Komisyon: %${strategy.commission || 0.05}
Başlangıç Sermayesi: $${strategy.start_capital || 1000}

Pariteler: ${symbols.join(', ')}
Dönem: Son ${period} gün

Her parite için gerçekçi backtest sonuçları üret. Komisyon ve kaldıraç etkisini hesapla. Maksimum düşüş, sharpe oranı ve profit factor dahil et.`,
        response_json_schema: {
          type: 'object',
          properties: {
            summary: { type: 'string' },
            overall: {
              type: 'object',
              properties: {
                total_trades: { type: 'number' },
                win_rate: { type: 'number' },
                total_pnl: { type: 'number' },
                max_drawdown: { type: 'number' },
                profit_factor: { type: 'number' },
                sharpe_ratio: { type: 'number' },
                avg_trade_duration: { type: 'string' },
                best_trade: { type: 'number' },
                worst_trade: { type: 'number' },
              }
            },
            symbol_results: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  symbol: { type: 'string' },
                  trades: { type: 'number' },
                  wins: { type: 'number' },
                  losses: { type: 'number' },
                  win_rate: { type: 'number' },
                  total_pnl: { type: 'number' },
                  max_drawdown: { type: 'number' },
                  profit_factor: { type: 'number' },
                  final_balance: { type: 'number' },
                  verdict: { type: 'string' },
                }
              }
            },
            ai_notes: { type: 'array', items: { type: 'string' } }
          }
        }
      });

      setResults(response);

      // AI öğrenme notlarını stratejiye kaydet (varsa DB'de)
      if (strategy.id && !strategy.id.startsWith('custom_') && response.ai_notes?.length) {
        const newNotes = (response.ai_notes || []).map(note => ({
          timestamp: new Date().toISOString(),
          type: 'insight',
          note,
          symbol: symbols.join(','),
          context: { period, win_rate: response.overall?.win_rate }
        }));
        const existingNotes = strategy.ai_learning_notes || [];
        await base44.entities.UserStrategy.update(strategy.id, {
          ai_learning_notes: [...existingNotes, ...newNotes].slice(-50)
        }).catch(() => {});
      }

      toast.success('Backtest tamamlandı!');
    } catch (err) {
      toast.error('Backtest çalıştırılamadı: ' + err.message);
    } finally {
      setRunning(false);
    }
  };

  const overall = results?.overall;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-end md:items-center justify-center p-0 md:p-4">
      <div className="bg-card border border-border rounded-t-2xl md:rounded-2xl w-full md:max-w-2xl max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border px-4 py-3 flex items-center justify-between rounded-t-2xl z-10">
          <div>
            <div className="text-sm font-bold flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-primary" /> Backtest & Performans Analizi
            </div>
            <div className="text-xs text-muted-foreground">{strategy.name}</div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-secondary">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Pariteler */}
          <div>
            <div className="text-xs font-semibold text-muted-foreground mb-2">Pariteler</div>
            <div className="flex flex-wrap gap-1.5">
              {POPULAR_PAIRS.map(p => (
                <button key={p}
                  onClick={() => toggleSymbol(p)}
                  className={cn(
                    "text-xs px-2.5 py-1 rounded-lg border transition-colors",
                    symbols.includes(p)
                      ? "bg-primary/20 border-primary text-primary font-semibold"
                      : "bg-secondary border-border text-muted-foreground hover:text-foreground"
                  )}
                >{p.replace('USDT', '')}</button>
              ))}
            </div>
          </div>

          {/* Dönem */}
          <div>
            <div className="text-xs font-semibold text-muted-foreground mb-2">Test Dönemi</div>
            <div className="flex gap-2">
              {PERIODS.map(p => (
                <button key={p.value}
                  onClick={() => setPeriod(p.value)}
                  className={cn(
                    "flex-1 text-xs py-1.5 rounded-lg border transition-colors",
                    period === p.value
                      ? "bg-primary/20 border-primary text-primary font-semibold"
                      : "bg-secondary border-border text-muted-foreground"
                  )}
                >{p.label}</button>
              ))}
            </div>
          </div>

          <Button onClick={runBacktest} disabled={running} className="w-full gap-2">
            {running
              ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Backtest Çalışıyor...</>
              : <><Play className="w-3.5 h-3.5" /> Backtest Başlat</>}
          </Button>

          {/* Genel Özet */}
          {overall && (
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <MetricCard label="Toplam İşlem" value={overall.total_trades} />
                <MetricCard label="Kazanç Oranı" value={`${overall.win_rate?.toFixed(1)}%`} green={overall.win_rate > 55} red={overall.win_rate < 45} />
                <MetricCard label="Toplam P&L" value={`$${overall.total_pnl?.toFixed(0)}`} green={overall.total_pnl > 0} red={overall.total_pnl < 0} />
                <MetricCard label="Max Düşüş" value={`${overall.max_drawdown?.toFixed(1)}%`} red />
                <MetricCard label="Profit Factor" value={overall.profit_factor?.toFixed(2)} green={overall.profit_factor > 1.5} red={overall.profit_factor < 1} />
                <MetricCard label="Sharpe Oranı" value={overall.sharpe_ratio?.toFixed(2)} green={overall.sharpe_ratio > 1} />
              </div>

              {/* Parite Bazlı */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-muted-foreground">Parite Bazlı Sonuçlar</div>
                {(results.symbol_results || []).map(r => (
                  <div key={r.symbol} className="bg-secondary/40 border border-border rounded-xl p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-bold">{r.symbol}</div>
                      <div className={cn(
                        "text-xs px-2 py-0.5 rounded-full font-medium",
                        r.total_pnl > 0 ? "bg-profit/10 text-profit" : "bg-loss/10 text-loss"
                      )}>
                        {r.verdict}
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-1 text-xs">
                      <div><span className="text-muted-foreground">İşlem: </span><span className="font-semibold">{r.trades}</span></div>
                      <div><span className="text-muted-foreground">Kazanç: </span><span className={cn("font-semibold", r.win_rate > 50 ? "text-profit" : "text-loss")}>{r.win_rate?.toFixed(0)}%</span></div>
                      <div><span className="text-muted-foreground">P&L: </span><span className={cn("font-semibold", r.total_pnl > 0 ? "text-profit" : "text-loss")}>${r.total_pnl?.toFixed(0)}</span></div>
                      <div><span className="text-muted-foreground">Max DD: </span><span className="font-semibold text-loss">{r.max_drawdown?.toFixed(1)}%</span></div>
                      <div><span className="text-muted-foreground">PF: </span><span className="font-semibold">{r.profit_factor?.toFixed(2)}</span></div>
                      <div><span className="text-muted-foreground">Bakiye: </span><span className={cn("font-semibold", r.final_balance > (strategy.start_capital || 1000) ? "text-profit" : "text-loss")}>${r.final_balance?.toFixed(0)}</span></div>
                    </div>
                  </div>
                ))}
              </div>

              {/* AI Notları */}
              {results.ai_notes?.length > 0 && (
                <div className="bg-primary/10 border border-primary/20 rounded-xl p-3 space-y-1.5">
                  <div className="text-xs font-semibold text-primary flex items-center gap-1.5">
                    <AlertTriangle className="w-3 h-3" /> AI Analiz Notları
                  </div>
                  {results.ai_notes.map((note, i) => (
                    <div key={i} className="text-xs text-foreground">• {note}</div>
                  ))}
                </div>
              )}

              {/* Özet */}
              {results.summary && (
                <div className="bg-secondary/60 rounded-xl p-3 text-xs text-muted-foreground">
                  {results.summary}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function MetricCard({ label, value, green, red }) {
  return (
    <div className="bg-secondary/60 rounded-lg p-2.5 text-center">
      <div className="text-xs text-muted-foreground mb-0.5">{label}</div>
      <div className={cn("text-sm font-bold", green && "text-profit", red && "text-loss")}>{value ?? '—'}</div>
    </div>
  );
}