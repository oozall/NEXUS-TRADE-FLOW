import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import { Play, X, Plus, Trash2, Loader2, TrendingUp, TrendingDown, BarChart2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';

const POPULAR_PAIRS = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT', 'AVAXUSDT', 'DOTUSDT', 'LINKUSDT'];
const TIMEFRAMES = ['1m', '5m', '15m', '30m', '1h', '4h', '1d'];

export default function ForwardTestPanel({ strategy, onClose }) {
  const [symbols, setSymbols] = useState(['BTCUSDT', 'ETHUSDT']);
  const [customSymbol, setCustomSymbol] = useState('');
  const [leverage, setLeverage] = useState(5);
  const [commission, setCommission] = useState(0.05);
  const [startCapital, setStartCapital] = useState(1000);
  const [timeframe, setTimeframe] = useState(strategy.timeframe || '15m');
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState(null);

  const addSymbol = (sym) => {
    const s = sym.toUpperCase().trim();
    if (!s || symbols.includes(s)) return;
    setSymbols(prev => [...prev, s]);
    setCustomSymbol('');
  };

  const removeSymbol = (sym) => setSymbols(prev => prev.filter(s => s !== sym));

  const runTest = async () => {
    if (symbols.length === 0) { toast.error('En az 1 parite seçin'); return; }
    setRunning(true);
    setResults(null);
    try {
      const prompt = `Sen bir kripto trading backtest ve forward test uzmanısın.

Strateji: "${strategy.name}"
Açıklama: ${strategy.description}
Giriş: ${strategy.entry_signal}
Çıkış: ${strategy.exit_signal}
Kurallar: ${(strategy.rules || []).join(', ')}
Beklenen Kazanç Oranı: ${strategy.expected_winrate}%
Risk/Reward: ${strategy.risk_reward}

Test Parametreleri:
- Pariteler: ${symbols.join(', ')}
- Zaman Dilimi: ${timeframe}
- Kaldıraç: ${leverage}x
- Komisyon: %${commission} per trade
- Başlangıç Sermayesi: $${startCapital}
- Test Periyodu: Son 90 gün (geçmiş) + Simüle ileriye dönük 30 gün

Her parite için hem backtest (geçmiş 90 gün) hem forward test (simüle 30 gün) sonuçlarını JSON olarak döndür.
Sonuçlar gerçekçi ve strateji özelliklerine uygun olmalı, komisyon ve kaldıraç etkisini hesaba kat.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            symbol_results: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  symbol: { type: 'string' },
                  backtest: {
                    type: 'object',
                    properties: {
                      trades: { type: 'number' },
                      wins: { type: 'number' },
                      losses: { type: 'number' },
                      win_rate: { type: 'number' },
                      total_pnl: { type: 'number' },
                      max_drawdown: { type: 'number' },
                      profit_factor: { type: 'number' },
                      final_balance: { type: 'number' },
                    }
                  },
                  forward_test: {
                    type: 'object',
                    properties: {
                      trades: { type: 'number' },
                      wins: { type: 'number' },
                      losses: { type: 'number' },
                      win_rate: { type: 'number' },
                      total_pnl: { type: 'number' },
                      max_drawdown: { type: 'number' },
                      profit_factor: { type: 'number' },
                      final_balance: { type: 'number' },
                    }
                  }
                }
              }
            },
            summary: { type: 'string' }
          }
        }
      });

      setResults(response);
      toast.success('Forward test tamamlandı!');
    } catch (err) {
      toast.error('Test çalıştırılamadı: ' + err.message);
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-end md:items-center justify-center p-0 md:p-4">
      <div className="bg-card border border-border rounded-t-2xl md:rounded-2xl w-full md:max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border px-4 py-3 flex items-center justify-between rounded-t-2xl">
          <div>
            <div className="text-sm font-bold">⚡ Forward Test</div>
            <div className="text-xs text-muted-foreground">{strategy.name}</div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-secondary">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Parite Seçimi */}
          <div>
            <div className="text-xs font-semibold text-muted-foreground mb-2">Pariteler</div>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {POPULAR_PAIRS.map(p => (
                <button
                  key={p}
                  onClick={() => symbols.includes(p) ? removeSymbol(p) : addSymbol(p)}
                  className={cn(
                    "text-xs px-2 py-1 rounded-md border transition-colors",
                    symbols.includes(p)
                      ? "bg-primary/20 border-primary text-primary"
                      : "bg-secondary border-border text-muted-foreground hover:text-foreground"
                  )}
                >{p.replace('USDT', '')}</button>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                className="flex-1 bg-background border border-border rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-primary"
                placeholder="Özel parite ekle (örn: SOLUSDT)"
                value={customSymbol}
                onChange={e => setCustomSymbol(e.target.value.toUpperCase())}
                onKeyDown={e => e.key === 'Enter' && addSymbol(customSymbol)}
              />
              <button onClick={() => addSymbol(customSymbol)} className="px-3 py-1.5 bg-secondary border border-border rounded-lg text-xs">
                <Plus className="w-3 h-3" />
              </button>
            </div>
            <div className="flex flex-wrap gap-1 mt-2">
              {symbols.map(s => (
                <span key={s} className="flex items-center gap-1 bg-primary/10 text-primary text-xs px-2 py-0.5 rounded-full">
                  {s}
                  <button onClick={() => removeSymbol(s)}><X className="w-2.5 h-2.5" /></button>
                </span>
              ))}
            </div>
          </div>

          {/* Parametreler */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Zaman Dilimi</label>
              <select
                value={timeframe}
                onChange={e => setTimeframe(e.target.value)}
                className="w-full bg-background border border-border rounded-lg px-2 py-1.5 text-xs focus:outline-none"
              >
                {TIMEFRAMES.map(tf => <option key={tf} value={tf}>{tf}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Başlangıç Sermayesi ($)</label>
              <input
                type="number"
                value={startCapital}
                onChange={e => setStartCapital(Number(e.target.value))}
                className="w-full bg-background border border-border rounded-lg px-2 py-1.5 text-xs focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Kaldıraç: <strong>{leverage}x</strong></label>
              <Slider value={[leverage]} onValueChange={([v]) => setLeverage(v)} min={1} max={50} step={1} />
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Komisyon: <strong>%{commission}</strong></label>
              <Slider value={[commission]} onValueChange={([v]) => setCommission(v)} min={0.01} max={0.5} step={0.01} />
            </div>
          </div>

          <Button onClick={runTest} disabled={running} className="w-full gap-2">
            {running ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Test Çalışıyor...</> : <><Play className="w-3.5 h-3.5" /> Testi Başlat</>}
          </Button>

          {/* Sonuçlar */}
          {results && (
            <div className="space-y-3">
              <div className="text-xs font-semibold text-foreground">Test Sonuçları</div>
              {(results.symbol_results || []).map(r => (
                <div key={r.symbol} className="bg-secondary/40 border border-border rounded-xl p-3">
                  <div className="text-sm font-bold mb-2">{r.symbol}</div>
                  <div className="grid grid-cols-2 gap-2">
                    {/* Backtest */}
                    <div className="bg-background/60 rounded-lg p-2">
                      <div className="text-xs text-muted-foreground font-semibold mb-2 flex items-center gap-1">
                        <BarChart2 className="w-3 h-3" /> Geçmiş Test (90g)
                      </div>
                      <ResultRow label="İşlem" val={r.backtest?.trades} />
                      <ResultRow label="Kazanç" val={`${r.backtest?.win_rate?.toFixed(0)}%`} green={r.backtest?.win_rate > 50} />
                      <ResultRow label="P&L" val={`$${r.backtest?.total_pnl?.toFixed(0)}`} green={r.backtest?.total_pnl > 0} red={r.backtest?.total_pnl < 0} />
                      <ResultRow label="Max DD" val={`${r.backtest?.max_drawdown?.toFixed(1)}%`} red />
                      <ResultRow label="Bakiye" val={`$${r.backtest?.final_balance?.toFixed(0)}`} green={r.backtest?.final_balance > startCapital} />
                    </div>
                    {/* Forward Test */}
                    <div className="bg-background/60 rounded-lg p-2">
                      <div className="text-xs text-muted-foreground font-semibold mb-2 flex items-center gap-1">
                        <TrendingUp className="w-3 h-3 text-primary" /> İleri Test (30g)
                      </div>
                      <ResultRow label="İşlem" val={r.forward_test?.trades} />
                      <ResultRow label="Kazanç" val={`${r.forward_test?.win_rate?.toFixed(0)}%`} green={r.forward_test?.win_rate > 50} />
                      <ResultRow label="P&L" val={`$${r.forward_test?.total_pnl?.toFixed(0)}`} green={r.forward_test?.total_pnl > 0} red={r.forward_test?.total_pnl < 0} />
                      <ResultRow label="Max DD" val={`${r.forward_test?.max_drawdown?.toFixed(1)}%`} red />
                      <ResultRow label="Bakiye" val={`$${r.forward_test?.final_balance?.toFixed(0)}`} green={r.forward_test?.final_balance > startCapital} />
                    </div>
                  </div>
                </div>
              ))}
              {results.summary && (
                <div className="bg-primary/10 border border-primary/20 rounded-lg p-3 text-xs text-foreground">
                  <strong>AI Özeti:</strong> {results.summary}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ResultRow({ label, val, green, red }) {
  return (
    <div className="flex justify-between text-xs py-0.5">
      <span className="text-muted-foreground">{label}</span>
      <span className={cn("font-semibold", green && "text-profit", red && "text-loss")}>{val ?? '-'}</span>
    </div>
  );
}