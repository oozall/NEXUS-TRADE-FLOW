import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import { X, Save, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';

const TIMEFRAMES = ['1m', '5m', '15m', '30m', '1h', '4h', '1d'];

export default function StrategyConfigPanel({ strategy, onClose, onSaved }) {
  const [name, setName] = useState(strategy.name || '');
  const [description, setDescription] = useState(strategy.description || '');
  const [entrySignal, setEntrySignal] = useState(strategy.entry_signal || '');
  const [exitSignal, setExitSignal] = useState(strategy.exit_signal || '');
  const [rules, setRules] = useState(strategy.rules || []);
  const [newRule, setNewRule] = useState('');
  const [timeframe, setTimeframe] = useState(strategy.timeframe || '15m');
  const [leverage, setLeverage] = useState(strategy.leverage || 5);
  const [commission, setCommission] = useState(strategy.commission || 0.05);
  const [startCapital, setStartCapital] = useState(strategy.start_capital || 1000);
  const [maxAssets, setMaxAssets] = useState(strategy.max_assets || 3);
  const [saving, setSaving] = useState(false);

  const addRule = () => {
    if (!newRule.trim()) return;
    setRules(prev => [...prev, newRule.trim()]);
    setNewRule('');
  };

  const removeRule = (idx) => setRules(prev => prev.filter((_, i) => i !== idx));

  const handleSave = async () => {
    setSaving(true);
    try {
      const data = {
        name, description, entry_signal: entrySignal, exit_signal: exitSignal,
        rules, timeframe, leverage, commission, start_capital: startCapital,
        max_assets: maxAssets, is_active: strategy.is_active ?? true,
        backtest: strategy.backtest,
        expected_winrate: strategy.expected_winrate,
        expected_loss_rate: strategy.expected_loss_rate,
        risk_reward: strategy.risk_reward,
      };
      if (strategy.id && !strategy.id.startsWith('custom_')) {
        await base44.entities.UserStrategy.update(strategy.id, data);
      } else {
        await base44.entities.UserStrategy.create(data);
      }
      toast.success('Strateji kaydedildi!');
      onSaved?.();
      onClose();
    } catch (err) {
      toast.error('Kaydedilemedi: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-end md:items-center justify-center p-0 md:p-4">
      <div className="bg-card border border-border rounded-t-2xl md:rounded-2xl w-full md:max-w-xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-card border-b border-border px-4 py-3 flex items-center justify-between rounded-t-2xl">
          <div className="text-sm font-bold">⚙️ Strateji Yapılandır</div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-secondary"><X className="w-4 h-4" /></button>
        </div>

        <div className="p-4 space-y-4">
          {/* Temel Bilgiler */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-muted-foreground">Temel Bilgiler</div>
            <div>
              <label className="text-xs text-muted-foreground">Strateji Adı</label>
              <input value={name} onChange={e => setName(e.target.value)}
                className="w-full mt-1 bg-background border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Açıklama</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} rows={2}
                className="w-full mt-1 bg-background border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary resize-none" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Giriş Sinyali</label>
              <textarea value={entrySignal} onChange={e => setEntrySignal(e.target.value)} rows={2}
                className="w-full mt-1 bg-background border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary resize-none" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Çıkış Sinyali</label>
              <textarea value={exitSignal} onChange={e => setExitSignal(e.target.value)} rows={2}
                className="w-full mt-1 bg-background border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary resize-none" />
            </div>
          </div>

          {/* Kurallar */}
          <div>
            <div className="text-xs font-semibold text-muted-foreground mb-2">Kurallar</div>
            <div className="space-y-1 mb-2">
              {rules.map((r, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-secondary/40 rounded-lg px-3 py-1.5 text-xs">
                  <span className="flex-1">• {r}</span>
                  <button onClick={() => removeRule(idx)}><Trash2 className="w-3 h-3 text-destructive" /></button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <input value={newRule} onChange={e => setNewRule(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addRule()}
                placeholder="Yeni kural ekle..."
                className="flex-1 bg-background border border-border rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-primary" />
              <button onClick={addRule} className="px-2.5 py-1.5 bg-primary rounded-lg"><Plus className="w-3.5 h-3.5 text-primary-foreground" /></button>
            </div>
          </div>

          {/* İleri Seviye Ayarlar */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-muted-foreground">İleri Seviye Ayarlar</div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground">Zaman Dilimi</label>
                <select value={timeframe} onChange={e => setTimeframe(e.target.value)}
                  className="w-full mt-1 bg-background border border-border rounded-lg px-2 py-1.5 text-xs focus:outline-none">
                  {TIMEFRAMES.map(tf => <option key={tf} value={tf}>{tf}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Başlangıç Sermayesi ($)</label>
                <input type="number" value={startCapital} onChange={e => setStartCapital(Number(e.target.value))}
                  className="w-full mt-1 bg-background border border-border rounded-lg px-2 py-1.5 text-xs focus:outline-none" />
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Max Kripto Varlık Sayısı: <strong>{maxAssets}</strong></label>
              <Slider value={[maxAssets]} onValueChange={([v]) => setMaxAssets(v)} min={1} max={20} step={1} />
              <div className="flex justify-between mt-0.5 text-xs text-muted-foreground"><span>1</span><span>10</span><span>20</span></div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Kaldıraç: <strong>{leverage}x</strong></label>
              <Slider value={[leverage]} onValueChange={([v]) => setLeverage(v)} min={1} max={50} step={1} />
              <div className="flex justify-between mt-0.5 text-xs text-muted-foreground"><span>1x</span><span>25x</span><span>50x</span></div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Komisyon: <strong>%{commission}</strong></label>
              <Slider value={[commission]} onValueChange={([v]) => setCommission(Math.round(v * 100) / 100)} min={0.01} max={0.5} step={0.01} />
              <div className="flex justify-between mt-0.5 text-xs text-muted-foreground"><span>%0.01</span><span>%0.25</span><span>%0.5</span></div>
            </div>
          </div>

          <Button onClick={handleSave} disabled={saving} className="w-full gap-2">
            {saving ? 'Kaydediliyor...' : <><Save className="w-3.5 h-3.5" /> Kaydet</>}
          </Button>
        </div>
      </div>
    </div>
  );
}